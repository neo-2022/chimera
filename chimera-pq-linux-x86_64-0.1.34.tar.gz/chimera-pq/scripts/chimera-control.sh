#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
STATE_FILE="${STATE_FILE:-$ROOT_DIR/docs/runtime_state_latest.json}"
GATEWAY_LOG="${GATEWAY_LOG:-$ROOT_DIR/docs/chimera_gateway.service.log}"
CLIENT_LOG="${CLIENT_LOG:-$ROOT_DIR/docs/chimera_client.service.log}"
UI_MODE_FILE="${UI_MODE_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/ui_mode}"
UPSTREAM_ENV_FILE="${UPSTREAM_ENV_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/upstream_proxy.env}"
CHIMERA_PROTECTED_PORTS_CSV="${CHIMERA_PROTECTED_PORTS_CSV:-11080,22180}"
CHIMERA_SAFE_HOST_LOCK="${CHIMERA_SAFE_HOST_LOCK:-1}"
CHIMERA_ALLOW_LOCAL_NETWORK_MUTATION="${CHIMERA_ALLOW_LOCAL_NETWORK_MUTATION:-0}"
POLICY_FILE="${POLICY_FILE:-$ROOT_DIR/configs/policy.runtime.conf}"
MANUAL_GATEWAY_DOMAINS_FILE="${MANUAL_GATEWAY_DOMAINS_FILE:-$ROOT_DIR/configs/manual_gateway_domains.txt}"
APP_ROUTES_FILE="${APP_ROUTES_FILE:-$ROOT_DIR/configs/chimera-app-routes.conf}"
PAC_FILE="${PAC_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/chimera-proxy.pac}"
ROUTE_MODE_FILE="${ROUTE_MODE_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/route_mode}"
SPLIT_LIST_MODE_FILE="${SPLIT_LIST_MODE_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/split_list_mode}"
AUTOFIX_SCRIPT="$ROOT_DIR/scripts/chimera-autofix.sh"
UPSTREAM_AUTOBOOTSTRAP_SCRIPT="${UPSTREAM_AUTOBOOTSTRAP_SCRIPT:-$ROOT_DIR/scripts/chimera_upstream_autobootstrap.sh}"
AUTOFIX_TIMEOUT="${CHIMERA_AUTOFIX_MAX_TIME:-25}"
UPSTREAM_SSH_KEY_FILE="${CHIMERA_UPSTREAM_SSH_KEY_FILE:-$HOME/.ssh/id_ed25519}"
CHIMERA_ALLOW_PGREP_KILL="${CHIMERA_ALLOW_PGREP_KILL:-0}"
AUTO_RESTART_CHROMIUM="${CHIMERA_AUTO_RESTART_CHROMIUM:-0}"
PROXY_AUTOSYNC="${CHIMERA_PROXY_AUTOSYNC:-1}"
CHIMERA_SYSTEM_INTEGRATION="${CHIMERA_SYSTEM_INTEGRATION:-0}"
UPSTREAM_STRATEGY="${CHIMERA_UPSTREAM_STRATEGY:-balanced}"
UPSTREAM_STICKY_SEC="${CHIMERA_UPSTREAM_STICKY_SEC:-120}"
LAST_ENDPOINT_FILE="${XDG_CACHE_HOME:-$HOME/.cache}/chimera/last_upstream_endpoint"
UPSTREAM_HEALTH_STATE_FILE="${XDG_CACHE_HOME:-$HOME/.cache}/chimera/upstream_health_state"
SITE_ADAPTIVE_DB_FILE="${SITE_ADAPTIVE_DB_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/site_adaptive_routes.db}"
SITE_AUTO_SEEDS_FILE="${SITE_AUTO_SEEDS_FILE:-$ROOT_DIR/configs/auto_failover_seeds.txt}"
SITE_AUTOWATCH_PID_FILE="${SITE_AUTOWATCH_PID_FILE:-${XDG_RUNTIME_DIR:-/tmp}/chimera-site-autowatch.pid}"
SITE_AUTOWATCH_INTERVAL_SEC="${SITE_AUTOWATCH_INTERVAL_SEC:-60}"
SITE_AUTOWATCH_ENABLED="${SITE_AUTOWATCH_ENABLED:-1}"
SITE_AUTO_DISCOVERY_ENABLED="${SITE_AUTO_DISCOVERY_ENABLED:-1}"
SITE_AUTO_DISCOVERY_LOOKBACK_SEC="${SITE_AUTO_DISCOVERY_LOOKBACK_SEC:-120}"
SITE_DISCOVERY_DOMAINS_FILE="${SITE_DISCOVERY_DOMAINS_FILE:-${XDG_CACHE_HOME:-$HOME/.cache}/chimera/discovered_domains.txt}"
SITE_FAILOVER_PROXY_THRESHOLD="${SITE_FAILOVER_PROXY_THRESHOLD:-1}"
SITE_FAILBACK_DIRECT_THRESHOLD="${SITE_FAILBACK_DIRECT_THRESHOLD:-3}"
SITE_ADAPTIVE_ENTRY_TTL_SEC="${SITE_ADAPTIVE_ENTRY_TTL_SEC:-86400}"
AUTOFIX_LOG_FILE="${AUTOFIX_LOG_FILE:-${XDG_CACHE_HOME:-$HOME/.cache}/chimera/autofix.log}"
CHIMERA_CLI_BIN="${CHIMERA_CLI_BIN:-$ROOT_DIR/bin/chimera-cli}"
CHIMERA_GATEWAY_BIN="${CHIMERA_GATEWAY_BIN:-$ROOT_DIR/bin/chimera-gateway}"
CHIMERA_RUNNER="${CHIMERA_RUNNER:-$ROOT_DIR/scripts/chimera-runner.sh}"
RUNTIME_BOOTSTRAP_SCRIPT="${RUNTIME_BOOTSTRAP_SCRIPT:-$ROOT_DIR/scripts/chimera_runtime_bootstrap.sh}"
SINGBOX_BIN="${SINGBOX_BIN:-${XDG_DATA_HOME:-$HOME/.local/share}/chimera-pq/runtime/singbox/sing-box}"
CLIENT_CONFIG_FILE="${CLIENT_CONFIG_FILE:-$ROOT_DIR/configs/client.conf}"
SPLIT_TRANSPARENT_ENABLED="${SPLIT_TRANSPARENT_ENABLED:-1}"
SPLIT_TRANSPARENT_TUN_NAME="${SPLIT_TRANSPARENT_TUN_NAME:-chimera-tun}"
SPLIT_TRANSPARENT_TUN_ADDR="${SPLIT_TRANSPARENT_TUN_ADDR:-172.19.0.1/30}"
SPLIT_TRANSPARENT_TUN_ADDR6="${SPLIT_TRANSPARENT_TUN_ADDR6:-fd5a:7c0a:1::1/126}"
SPLIT_TRANSPARENT_AUTO_REDIRECT="${SPLIT_TRANSPARENT_AUTO_REDIRECT:-1}"
SPLIT_TRANSPARENT_CONFIG_FILE="${SPLIT_TRANSPARENT_CONFIG_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/singbox-split.json}"
SPLIT_TRANSPARENT_PID_FILE="${SPLIT_TRANSPARENT_PID_FILE:-${XDG_CACHE_HOME:-$HOME/.cache}/chimera/chimera-singbox.pid}"
SPLIT_TRANSPARENT_LOG_FILE="${SPLIT_TRANSPARENT_LOG_FILE:-${XDG_CACHE_HOME:-$HOME/.cache}/chimera/singbox-split.log}"
SPLIT_TRANSPARENT_LOG_LEVEL="${SPLIT_TRANSPARENT_LOG_LEVEL:-warn}"
SPLIT_TRANSPARENT_DNS_STRATEGY="${SPLIT_TRANSPARENT_DNS_STRATEGY:-prefer_ipv4}"
SPLIT_TRANSPARENT_WATCHDOG_PID_FILE="${SPLIT_TRANSPARENT_WATCHDOG_PID_FILE:-${XDG_CACHE_HOME:-$HOME/.cache}/chimera/chimera-split-watchdog.pid}"
CHIMERA_ALLOW_WEAVE_COEXIST_MUTATION="${CHIMERA_ALLOW_WEAVE_COEXIST_MUTATION:-0}"
CHIMERA_COEXIST_TRANSPARENT_CAPTURE="${CHIMERA_COEXIST_TRANSPARENT_CAPTURE:-1}"
CHIMERA_FORCE_PROXY_NONE="${CHIMERA_FORCE_PROXY_NONE:-0}"
CHIMERA_REQUIRE_UPSTREAM_FOR_FAILOVER="${CHIMERA_REQUIRE_UPSTREAM_FOR_FAILOVER:-1}"
CHIMERA_STRICT_FAILOVER_GATE="${CHIMERA_STRICT_FAILOVER_GATE:-1}"
NFT_BIN="${NFT_BIN:-}"

find_matching_tunnel_port() {
  local host="${1:-}"
  local user="${2:-}"
  if [[ -z "$host" || -z "$user" ]]; then
    return 1
  fi
  ps -eo args= 2>/dev/null | awk -v h="$host" -v u="$user" '
    /ssh/ && / -N / && / -D / {
      if (index($0, u "@" h) == 0) {
        next
      }
      for (i = 1; i <= NF; i++) {
        if ($i == "-D" && i + 1 <= NF) {
          split($(i+1), hp, ":")
          p = hp[length(hp)]
          if (p ~ /^[0-9]+$/) {
            print p
            exit
          }
        }
      }
    }'
}

upsert_env_kv() {
  local file="${1:?file_required}"
  local key="${2:?key_required}"
  local value="${3:-}"
  mkdir -p "$(dirname "$file")"
  touch "$file"
  if grep -qE "^${key}=" "$file"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    printf '%s=%s\n' "$key" "$value" >> "$file"
  fi
}

pid_cmdline_contains() {
  local pid="${1:-}"
  local needle="${2:-}"
  [[ -n "$pid" && -n "$needle" ]] || return 1
  [[ -r "/proc/$pid/cmdline" ]] || return 1
  tr '\0' ' ' <"/proc/$pid/cmdline" | grep -Fq -- "$needle"
}

ensure_upstream_env_bootstrapped() {
  count_candidates_csv() {
    local raw="${1:-}"
    local count=0 item
    IFS=',' read -r -a arr <<<"$raw"
    for item in "${arr[@]}"; do
      item="$(trim_ascii "$item")"
      [[ -z "$item" ]] && continue
      count=$((count + 1))
    done
    echo "$count"
  }

  local need_bootstrap="1"
  local existing_user="" existing_pass="" existing_candidates_csv=""
  if [[ -f "$UPSTREAM_ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_ENV_FILE"
    existing_user="${CHIMERA_UPSTREAM_USER:-}"
    existing_pass="${CHIMERA_UPSTREAM_PASS:-}"
    existing_candidates_csv="${CHIMERA_UPSTREAM_ENDPOINTS_CSV:-}"
    if [[ -n "${CHIMERA_UPSTREAM_USER:-}" && -n "${CHIMERA_UPSTREAM_HOST:-}" && -n "${CHIMERA_UPSTREAM_PASS:-}" ]]; then
      need_bootstrap="0"
    fi
  fi

  local candidate_count="0"
  candidate_count="$(count_candidates_csv "$existing_candidates_csv")"
  # Force re-bootstrap when we have only a single egress candidate.
  if [[ "$need_bootstrap" == "0" && "$candidate_count" =~ ^[0-9]+$ && "$candidate_count" -lt 2 ]]; then
    need_bootstrap="1"
  fi

  if [[ "$need_bootstrap" == "1" && -x "$UPSTREAM_AUTOBOOTSTRAP_SCRIPT" ]]; then
    CHIMERA_UPSTREAM_POOL_USER="${CHIMERA_UPSTREAM_POOL_USER:-$existing_user}" \
    CHIMERA_UPSTREAM_POOL_PASS="${CHIMERA_UPSTREAM_POOL_PASS:-$existing_pass}" \
    UPSTREAM_ENV_FILE="$UPSTREAM_ENV_FILE" \
    "$UPSTREAM_AUTOBOOTSTRAP_SCRIPT" >/dev/null 2>&1 || true
  fi
}

usage() {
  cat <<'EOF'
Usage: chimera-control.sh <command>

Commands:
  start          Start CHIMERA gateway+client services (systemd --user)
  stop           Stop CHIMERA gateway+client services
  restart        Restart CHIMERA services
  status         Show status for CHIMERA services and runtime state
  doctor         Run client doctor check
  logs           Tail gateway+client logs
  proxy-status   Show transparent runtime and route status
  app-routes-status  Show parsed app/service routing config
  route-status       Show split routing runtime status
  run-app <app_id> [args...]
                Run selected app under the transparent runtime
  verify-app <app_id> [args...]
                Verify app run under the transparent runtime
  verify-cmd <command...>
                Verify any command/binary under the transparent runtime
  service-proxy-enable [service...]
                Retired legacy command; transparent runtime is the default
  service-proxy-disable [service...]
                Retired legacy command; transparent runtime is the default
  verify-service <service...>
                Retired legacy command; transparent runtime is the default
  route-mode [show|full|split|off]
                Set/get CHIMERA routing mode
  split-list-mode [show|allow|deny]
                Set/get split domain list mode:
                allow = only listed domains go through CHIMERA
                deny  = listed domains go direct, all others through CHIMERA
  site-add <domain...>
                Add site domains to CHIMERA split list and apply
  site-remove <domain...>
                Remove site domains from CHIMERA split list and apply
  site-list     Show CHIMERA split site list
  site-auto-resolve <domain...>
                Auto-pick working path for domains and persist decision
  site-auto-status
                Show learned adaptive site decisions
  site-auto-bootstrap
                Seed adaptive DB from known targets and resolve routes now
  site-auto-discover [run|status|clear]
                Discover recent system DNS domains and feed adaptive split logic
  site-auto-watch [start|stop|status|run-once]
                Background adaptive recheck and auto re-pick
  split-transparent [start|stop|status|refresh]
                System-level split capture via transparent TUN runtime
  grant-perms
                Grant CHIMERA runtime sudo permissions for network operations
  preflight-perms [--warn-only]
                Verify required privileges/capabilities before runtime start
  upstream-probe
                Show candidate upstream endpoints and measured connect latency
  upstream-reset
                Clear upstream sticky/health state and force fresh endpoint choice
  upstream-audit [lines]
                Show upstream health snapshot + recent watchdog switch history
  upstream-failover-smoke [wait_sec]
                Force local tunnel drop and print recovery audit
  apps-running  Show running applications (process names)
  services-running
                Show running user services
  mesh <args...>
                Pass through to chimera-cli mesh <args...>
  app-route-add <app_id> <command>
                Add/update app route entry in config
  app-route-add-running <process_name...>
                Add running processes as app routes automatically
  service-proxy-enable-running [service...]
                Enable CHIMERA proxy for running user services
  uninstall      Full uninstall + OS/network settings cleanup (best-effort, idempotent)
  ui-mode        Show or set UI mode override: auto|tray|dialog|cli

Safety defaults:
  CHIMERA_SYSTEM_INTEGRATION=0 (default) keeps CHIMERA isolated and prevents
  global desktop proxy or third-party app modifications.
EOF
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "error: required command not found: $1" >&2
    exit 1
  }
}

ensure_base_path() {
  export PATH="$HOME/.local/bin:$PATH"
}

client_config_path() {
  if [[ -f "$CLIENT_CONFIG_FILE" ]]; then
    echo "$CLIENT_CONFIG_FILE"
    return 0
  fi
  echo "$ROOT_DIR/configs/client.example.conf"
}

client_config_ready() {
  local config_path addr
  config_path="$(client_config_path)"
  [[ -f "$config_path" ]] || return 1
  addr="$(awk -F'= ' '$1=="carrier.addr" {print $2; exit}' "$config_path" 2>/dev/null || true)"
  case "$addr" in
    ""|203.0.113.10:443|127.0.0.1:443) return 1 ;;
    *) return 0 ;;
  esac
}

run_chimera_cli() {
  if [[ -x "$CHIMERA_RUNNER" ]]; then
    "$CHIMERA_RUNNER" cli "$@"
    return $?
  fi
  if [[ -x "$CHIMERA_CLI_BIN" ]]; then
    "$CHIMERA_CLI_BIN" "$@"
    return $?
  fi
  if [[ "${CHIMERA_ALLOW_CARGO_FALLBACK:-0}" == "1" ]] && command -v cargo >/dev/null 2>&1; then
    (
      cd "$ROOT_DIR"
      cargo run -q -p chimera-cli -- "$@"
    )
    return $?
  fi
  echo "error: chimera-cli binary is missing and cargo fallback is disabled" >&2
  return 1
}

run_chimera_gateway() {
  if [[ -x "$CHIMERA_RUNNER" ]]; then
    "$CHIMERA_RUNNER" gateway "$@"
    return $?
  fi
  if [[ -x "$CHIMERA_GATEWAY_BIN" ]]; then
    "$CHIMERA_GATEWAY_BIN" "$@"
    return $?
  fi
  if [[ "${CHIMERA_ALLOW_CARGO_FALLBACK:-0}" == "1" ]] && command -v cargo >/dev/null 2>&1; then
    (
      cd "$ROOT_DIR"
      cargo run -q -p chimera-gateway -- "$@"
    )
    return $?
  fi
  echo "error: chimera-gateway binary is missing and cargo fallback is disabled" >&2
  return 1
}

systemd_user_ready() {
  command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1
}

systemd_chimera_units_present() {
  local units
  units="$(systemctl --user list-unit-files 2>/dev/null || true)"
  if command -v rg >/dev/null 2>&1; then
    printf '%s\n' "$units" | rg -q '^chimera-gateway\.service|^chimera-client\.service'
  else
    printf '%s\n' "$units" | grep -Eq '^chimera-gateway\.service|^chimera-client\.service'
  fi
}

systemd_units_active_ok() {
  local client_expected="${1:-1}"
  local gateway_state client_state
  gateway_state="$(systemctl --user is-active chimera-gateway.service 2>/dev/null || true)"
  client_state="$(systemctl --user is-active chimera-client.service 2>/dev/null || true)"
  if [[ "$client_expected" == "1" ]]; then
    [[ "$gateway_state" == "active" && "$client_state" == "active" ]]
  else
    [[ "$gateway_state" == "active" ]]
  fi
}

desktop_proxy_supported() {
  if ! command -v gsettings >/dev/null 2>&1; then
    return 1
  fi
  gsettings list-schemas 2>/dev/null | grep -qx 'org.gnome.system.proxy'
}

read_route_mode() {
  if [[ -f "$ROUTE_MODE_FILE" ]]; then
    local mode
    mode="$(tr -d '[:space:]' < "$ROUTE_MODE_FILE" | tr '[:upper:]' '[:lower:]')"
    case "$mode" in
      full|split|off) echo "$mode"; return 0 ;;
      selective) echo "split"; return 0 ;;
    esac
  fi
  echo "split"
}

write_route_mode() {
  local mode="${1:-split}"
  if [[ "$mode" == "selective" ]]; then
    mode="split"
  fi
  mkdir -p "$(dirname "$ROUTE_MODE_FILE")"
  printf '%s\n' "$mode" > "$ROUTE_MODE_FILE"
}

read_split_list_mode() {
  if [[ -f "$SPLIT_LIST_MODE_FILE" ]]; then
    local mode
    mode="$(tr -d '[:space:]' < "$SPLIT_LIST_MODE_FILE" | tr '[:upper:]' '[:lower:]')"
    case "$mode" in
      allow|deny) echo "$mode"; return 0 ;;
    esac
  fi
  echo "allow"
}

write_split_list_mode() {
  local mode="${1:-allow}"
  case "$mode" in
    allow|deny) ;;
    *) mode="allow" ;;
  esac
  mkdir -p "$(dirname "$SPLIT_LIST_MODE_FILE")"
  printf '%s\n' "$mode" > "$SPLIT_LIST_MODE_FILE"
}

trim_ascii() {
  local s="${1:-}"
  s="${s#"${s%%[![:space:]]*}"}"
  s="${s%"${s##*[![:space:]]}"}"
  printf '%s' "$s"
}

split_csv_lines() {
  local csv="${1:-}"
  IFS=',' read -r -a out <<<"$csv"
  local item
  for item in "${out[@]}"; do
    item="$(trim_ascii "$item")"
    [[ -z "$item" ]] && continue
    printf '%s\n' "$item"
  done
}

is_protected_port() {
  local port="${1:-}"
  [[ "$port" =~ ^[0-9]+$ ]] || return 1
  local p
  while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    if [[ "$p" == "$port" ]]; then
      return 0
    fi
  done < <(split_csv_lines "$CHIMERA_PROTECTED_PORTS_CSV")
  return 1
}

ensure_safe_local_host_guard() {
  [[ "$CHIMERA_SAFE_HOST_LOCK" == "1" ]] || return 0
  if [[ "$CHIMERA_ALLOW_LOCAL_NETWORK_MUTATION" != "1" ]]; then
    # Adaptive safe-profile: do not block command, just prevent risky global mutations.
    SPLIT_TRANSPARENT_ENABLED="0"
    CHIMERA_SYSTEM_INTEGRATION="0"
    echo "chimera_local_safety_profile=active action=disable_system_mutation"
  fi
}

foreign_vpn_contours_present() {
  # If host already has non-CHIMERA WEAVE stack, avoid route/tun mutations by default.
  if pgrep -f '/usr/sbin/openvpn|wg-quick|wireguard|xray|hysteria' >/dev/null 2>&1; then
    return 0
  fi
  # Detect non-CHIMERA sing-box by config path.
  if pgrep -af 'sing-box run -c ' 2>/dev/null | grep -vE 'chimera|singbox-split\.json' >/dev/null 2>&1; then
    return 0
  fi
  return 1
}

is_local_upstream_host() {
  local host="${1:-}"
  host="$(trim_ascii "${host,,}")"
  [[ -z "$host" ]] && return 0
  [[ "$host" == "localhost" ]] && return 0
  [[ "$host" == "127.0.0.1" ]] && return 0
  [[ "$host" == "::1" ]] && return 0
  return 1
}

ensure_vpn_coexist_guard() {
  if [[ "$CHIMERA_ALLOW_WEAVE_COEXIST_MUTATION" == "1" ]]; then
    return 0
  fi
  if foreign_vpn_contours_present; then
    CHIMERA_SYSTEM_INTEGRATION="0"
    if [[ "$CHIMERA_COEXIST_TRANSPARENT_CAPTURE" == "1" ]]; then
      SPLIT_TRANSPARENT_ENABLED="1"
      PROXY_AUTOSYNC="0"
      CHIMERA_FORCE_PROXY_NONE="1"
      echo "chimera_coexist_guard=active action=disable_desktop_proxy_only reason=foreign_vpn_contours_detected"
      echo "chimera_coexist_transparent_capture=enabled mode=kernel_tun_split"
    else
      SPLIT_TRANSPARENT_ENABLED="0"
      echo "chimera_coexist_guard=active action=disable_system_mutation reason=foreign_vpn_contours_detected"
    fi
  fi
}

run_permissions_preflight() {
  local warn_only="${1:-0}"
  local failed=0
  local tmp_tun="chpq$((RANDOM % 900 + 100))"
  local pid_dir
  local sudo_cmd_ok=1
  pid_dir="$(dirname "$SPLIT_TRANSPARENT_PID_FILE")"
  echo "preflight_kind=permissions"
  sudo -n ip -Version >/dev/null 2>&1 || sudo_cmd_ok=0
  if [[ -e /dev/net/tun ]]; then
    echo "check_dev_net_tun=ok"
  else
    echo "check_dev_net_tun=fail"
    failed=1
  fi
  if sudo -n ip tuntap add dev "$tmp_tun" mode tun >/dev/null 2>&1; then
    sudo -n ip link del "$tmp_tun" >/dev/null 2>&1 || true
    echo "check_tun_create=ok"
  else
    echo "check_tun_create=fail"
    failed=1
  fi
  local nft_cmd="$NFT_BIN"
  if [[ -z "$nft_cmd" ]]; then
    if command -v nft >/dev/null 2>&1; then
      nft_cmd="$(command -v nft)"
    elif [[ -x /usr/sbin/nft ]]; then
      nft_cmd="/usr/sbin/nft"
    fi
  fi
  if [[ -n "$nft_cmd" ]]; then
    sudo -n "$nft_cmd" --version >/dev/null 2>&1 || sudo_cmd_ok=0
    if sudo -n "$nft_cmd" list ruleset >/dev/null 2>&1; then
      echo "check_nft_access=ok"
    else
      echo "check_nft_access=fail"
      failed=1
    fi
  else
    echo "check_nft_access=missing"
    failed=1
  fi
  if sudo -n ip rule show >/dev/null 2>&1; then
    echo "check_iprule_access=ok"
  else
    echo "check_iprule_access=fail"
    failed=1
  fi
  if [[ "$sudo_cmd_ok" -eq 1 ]]; then
    echo "check_sudo_nopass=ok"
  else
    echo "check_sudo_nopass=fail"
    failed=1
  fi
  if mkdir -p "$pid_dir" >/dev/null 2>&1 && [[ -w "$pid_dir" ]]; then
    echo "check_pid_dir_writable=ok dir=$pid_dir"
  else
    echo "check_pid_dir_writable=fail dir=$pid_dir"
    failed=1
  fi
  if [[ "$failed" -eq 0 ]]; then
    echo "preflight_status=ok"
    return 0
  fi
  echo "preflight_status=fail"
  echo "preflight_hint=grant_required_permissions_and_reinstall_or_run_chimera_control_preflight_perms"
  if [[ "$warn_only" -eq 1 ]]; then
    return 0
  fi
  return 2
}

grant_runtime_permissions() {
  local user_name=""
  user_name="${SUDO_USER:-$USER}"
  if [[ -z "$user_name" ]]; then
    echo "grant_perms_status=fail reason=user_not_detected"
    return 2
  fi
  local sudoers_dir="/etc/sudoers.d"
  local sudoers_file="$sudoers_dir/chimera-pq"
  local tmp_file
  tmp_file="$(mktemp)"
  cat >"$tmp_file" <<EOF
# Managed by CHIMERA installer/runtime.
Cmnd_Alias CHIMERA_NET_CMDS = /usr/bin/ip, /usr/sbin/ip, /usr/bin/nft, /usr/sbin/nft, /usr/bin/modprobe, /usr/sbin/modprobe
${user_name} ALL=(root) NOPASSWD: CHIMERA_NET_CMDS
EOF

  if ! sudo mkdir -p "$sudoers_dir"; then
    rm -f "$tmp_file"
    echo "grant_perms_status=fail reason=sudoers_dir_create_failed"
    return 2
  fi
  if ! sudo install -m 0440 "$tmp_file" "$sudoers_file"; then
    rm -f "$tmp_file"
    echo "grant_perms_status=fail reason=sudoers_write_failed"
    return 2
  fi
  rm -f "$tmp_file"

  if command -v visudo >/dev/null 2>&1; then
    if ! sudo visudo -cf "$sudoers_file" >/dev/null 2>&1; then
      sudo rm -f "$sudoers_file" >/dev/null 2>&1 || true
      echo "grant_perms_status=fail reason=sudoers_validation_failed"
      return 2
    fi
  fi
  if [[ ! -e /dev/net/tun ]]; then
    sudo modprobe tun >/dev/null 2>&1 || true
  fi
  echo "grant_perms_status=ok"
  echo "grant_perms_file=$sudoers_file"
  return 0
}

build_upstream_candidates() {
  local out=()
  if [[ -n "${CHIMERA_UPSTREAM_TRANSPORTS_CSV:-}" ]]; then
    local entry
    while IFS= read -r entry; do
      [[ -z "$entry" ]] && continue
      out+=("$entry")
    done < <(split_csv_lines "$CHIMERA_UPSTREAM_TRANSPORTS_CSV")
  fi
  if [[ -n "${CHIMERA_UPSTREAM_ENDPOINTS_CSV:-}" ]]; then
    local entry
    while IFS= read -r entry; do
      [[ -z "$entry" ]] && continue
      out+=("$entry")
    done < <(split_csv_lines "$CHIMERA_UPSTREAM_ENDPOINTS_CSV")
  fi
  if [[ "${#out[@]}" -eq 0 && -n "${CHIMERA_UPSTREAM_HOST:-}" ]]; then
    if ! is_local_upstream_host "${CHIMERA_UPSTREAM_HOST}"; then
      out+=("${CHIMERA_UPSTREAM_HOST}:${CHIMERA_UPSTREAM_PORT:-22}")
    fi
  fi
  local item parsed endpoint host
  for item in "${out[@]}"; do
    parsed="$(parse_transport_endpoint "$item" || true)"
    endpoint="${parsed#*|}"
    host="${endpoint%:*}"
    if is_local_upstream_host "$host"; then
      continue
    fi
    printf '%s\n' "$item"
  done
}

count_upstream_candidates() {
  local n=0 line
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    n=$((n + 1))
  done < <(build_upstream_candidates)
  echo "$n"
}

parse_transport_endpoint() {
  local candidate="${1:-}"
  local transport="ssh"
  local endpoint="$candidate"
  if [[ "$candidate" == *@* ]]; then
    transport="${candidate%%@*}"
    endpoint="${candidate#*@}"
  fi
  transport="$(trim_ascii "${transport,,}")"
  endpoint="$(trim_ascii "$endpoint")"
  if [[ -z "$endpoint" ]]; then
    return 1
  fi
  local host="${endpoint%:*}"
  local port="${endpoint##*:}"
  if [[ "$host" == "$port" ]]; then
    case "$transport" in
      ssh443|ssh-443|tls|tcp443) port="443" ;;
      ssh8443|ssh-8443|tcp8443) port="8443" ;;
      *) port="${CHIMERA_UPSTREAM_PORT:-22}" ;;
    esac
    endpoint="${host}:${port}"
  fi
  printf '%s|%s\n' "$transport" "$endpoint"
}

endpoint_latency_ms_probe() {
  local parsed endpoint
  parsed="$(parse_transport_endpoint "${1:-}" || true)"
  endpoint="${parsed#*|}"
  local host="${endpoint%:*}"
  local port="${endpoint##*:}"
  [[ -z "$host" || -z "$port" ]] && echo 2147483647 && return 0
  local start end
  start="$(date +%s 2>/dev/null || echo 0)"
  if timeout 2 bash -lc "</dev/tcp/$host/$port" >/dev/null 2>&1; then
    end="$(date +%s 2>/dev/null || echo 0)"
    if [[ "$start" =~ ^[0-9]+$ && "$end" =~ ^[0-9]+$ && "$end" -ge "$start" ]]; then
      echo $(((end - start) * 1000))
    else
      echo 1
    fi
  else
    echo 2147483647
  fi
}

upstream_probe() {
  if [[ -f "$UPSTREAM_ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_ENV_FILE"
  fi
  local endpoint lat parsed transport endpoint_only
  local best="" best_lat=2147483647
  while IFS= read -r endpoint; do
    [[ -z "$endpoint" ]] && continue
    parsed="$(parse_transport_endpoint "$endpoint" || true)"
    transport="${parsed%%|*}"
    endpoint_only="${parsed#*|}"
    lat="$(endpoint_latency_ms_probe "$endpoint")"
    echo "upstream_candidate transport=${transport:-unknown} endpoint=${endpoint_only:-unknown} latency_ms=$lat"
    if [[ "$lat" =~ ^[0-9]+$ ]] && [[ "$lat" -lt "$best_lat" ]]; then
      best_lat="$lat"
      best="$endpoint_only"
    fi
  done < <(build_upstream_candidates)
  if [[ -n "$best" ]]; then
    echo "upstream_best endpoint=$best latency_ms=$best_lat strategy=$UPSTREAM_STRATEGY"
  else
    echo "upstream_best endpoint=none"
  fi
}

upstream_reset() {
  rm -f "$LAST_ENDPOINT_FILE" "$UPSTREAM_HEALTH_STATE_FILE"
  echo "upstream_state_reset=ok"
}

upstream_audit() {
  local lines="${1:-30}"
  if ! [[ "$lines" =~ ^[0-9]+$ ]]; then
    lines=30
  fi
  if [[ -f "$UPSTREAM_ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_ENV_FILE"
  fi
  echo "upstream_audit_begin"
  echo "upstream_strategy=$UPSTREAM_STRATEGY"
  local candidates_total
  candidates_total="$(count_upstream_candidates)"
  echo "upstream_candidates_total=$candidates_total"
  if [[ "$candidates_total" =~ ^[0-9]+$ ]] && [[ "$candidates_total" -ge 2 ]]; then
    echo "upstream_adaptation_possible=true"
  else
    echo "upstream_adaptation_possible=false"
  fi
  if [[ -f "$LAST_ENDPOINT_FILE" ]]; then
    echo "upstream_last_endpoint=$(awk -F'|' 'NR==1{print $1}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
    echo "upstream_last_endpoint_sticky_until=$(awk -F'|' 'NR==1{print $2}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
  else
    echo "upstream_last_endpoint=unknown"
  fi
  if [[ -f "$UPSTREAM_HEALTH_STATE_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_HEALTH_STATE_FILE"
    echo "upstream_health_listener_up=${listener_up:-unknown}"
    echo "upstream_health_ok=${health_ok:-unknown}"
    echo "upstream_degrade_fails=${degrade_fails:-unknown}"
    echo "upstream_degrade_threshold=${degrade_threshold:-unknown}"
    echo "upstream_last_reason=${last_reason:-unknown}"
    echo "upstream_last_transport=${last_transport:-unknown}"
    echo "upstream_health_ts=${ts:-unknown}"
  else
    echo "upstream_health_state=missing"
  fi
  echo "upstream_probe_now:"
  upstream_probe
  if [[ -f "${XDG_CACHE_HOME:-$HOME/.cache}/chimera/singbox-split.log" ]]; then
    echo "upstream_recent_events:"
    tail -n "$lines" "${XDG_CACHE_HOME:-$HOME/.cache}/chimera/singbox-split.log" | grep -E 'route|failover|reason=' || true
  fi
  echo "upstream_audit_end"
}

upstream_failover_smoke() {
  local wait_sec="${1:-10}"
  if ! [[ "$wait_sec" =~ ^[0-9]+$ ]]; then
    wait_sec=10
  fi
  echo "upstream_failover_smoke=transparent_runtime"
  split_transparent_status
  sleep "$wait_sec"
  upstream_audit 200
}
