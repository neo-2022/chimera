#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
STATE_FILE="${STATE_FILE:-$ROOT_DIR/docs/runtime_state_latest.json}"
GATEWAY_LOG="${GATEWAY_LOG:-$ROOT_DIR/docs/chimera_gateway.service.log}"
CLIENT_LOG="${CLIENT_LOG:-$ROOT_DIR/docs/chimera_client.service.log}"
UI_MODE_FILE="${UI_MODE_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/ui_mode}"
UPSTREAM_ENV_FILE="${UPSTREAM_ENV_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/upstream_proxy.env}"
SOCKS_HOST="${SOCKS_HOST:-127.0.0.1}"
SOCKS_PORT="${SOCKS_PORT:-11080}"
SOCKS_HEALTHCHECK_URL="${SOCKS_HEALTHCHECK_URL:-https://api.ipify.org}"
SOCKS_HEALTHCHECK_TIMEOUT_SEC="${SOCKS_HEALTHCHECK_TIMEOUT_SEC:-6}"
POLICY_FILE="${POLICY_FILE:-$ROOT_DIR/configs/policy.runtime.conf}"
MANUAL_GATEWAY_DOMAINS_FILE="${MANUAL_GATEWAY_DOMAINS_FILE:-$ROOT_DIR/configs/manual_gateway_domains.txt}"
APP_ROUTES_FILE="${APP_ROUTES_FILE:-$ROOT_DIR/configs/chimera-app-routes.conf}"
PAC_FILE="${PAC_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/chimera-proxy.pac}"
ROUTE_MODE_FILE="${ROUTE_MODE_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/route_mode}"
SPLIT_LIST_MODE_FILE="${SPLIT_LIST_MODE_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/split_list_mode}"
AUTOFIX_SCRIPT="$ROOT_DIR/scripts/chimera-autofix.sh"
WATCHDOG_SCRIPT="$ROOT_DIR/scripts/chimera-socks-watchdog.sh"
AUTOFIX_TIMEOUT="${CHIMERA_AUTOFIX_MAX_TIME:-25}"
WATCHDOG_PID_FILE="${XDG_RUNTIME_DIR:-/tmp}/chimera-socks-watchdog.pid"
AUTO_RESTART_CHROMIUM="${CHIMERA_AUTO_RESTART_CHROMIUM:-1}"
PROXY_AUTOSYNC="${CHIMERA_PROXY_AUTOSYNC:-1}"
UPSTREAM_STRATEGY="${CHIMERA_UPSTREAM_STRATEGY:-balanced}"
UPSTREAM_STICKY_SEC="${CHIMERA_UPSTREAM_STICKY_SEC:-120}"
LAST_ENDPOINT_FILE="${XDG_CACHE_HOME:-$HOME/.cache}/chimera/last_upstream_endpoint"
UPSTREAM_HEALTH_STATE_FILE="${XDG_CACHE_HOME:-$HOME/.cache}/chimera/upstream_health_state"
SITE_ADAPTIVE_DB_FILE="${SITE_ADAPTIVE_DB_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/chimera/site_adaptive_routes.db}"
SITE_AUTOWATCH_PID_FILE="${SITE_AUTOWATCH_PID_FILE:-${XDG_RUNTIME_DIR:-/tmp}/chimera-site-autowatch.pid}"
SITE_AUTOWATCH_INTERVAL_SEC="${SITE_AUTOWATCH_INTERVAL_SEC:-60}"
SITE_AUTOWATCH_ENABLED="${SITE_AUTOWATCH_ENABLED:-1}"
AUTOFIX_LOG_FILE="${AUTOFIX_LOG_FILE:-${XDG_CACHE_HOME:-$HOME/.cache}/chimera/autofix.log}"
CHIMERA_CLI_BIN="${CHIMERA_CLI_BIN:-$ROOT_DIR/bin/chimera-cli}"
CHIMERA_GATEWAY_BIN="${CHIMERA_GATEWAY_BIN:-$ROOT_DIR/bin/chimera-gateway}"
CHIMERA_RUNNER="${CHIMERA_RUNNER:-$ROOT_DIR/scripts/chimera-runner.sh}"

find_matching_tunnel_port() {
  local host="${1:-}"
  local user="${2:-}"
  if [[ -z "$host" || -z "$user" ]]; then
    return 1
  fi
  ps -eo args= 2>/dev/null | awk -v h="$host" -v u="$user" '
    /ssh/ && / -N / && / -D / {
      if (index($0, u "@" h) == 0) {
        next
      }
      for (i = 1; i <= NF; i++) {
        if ($i == "-D" && i + 1 <= NF) {
          split($(i+1), hp, ":")
          p = hp[length(hp)]
          if (p ~ /^[0-9]+$/) {
            print p
            exit
          }
        }
      }
    }'
}

is_port_busy() {
  local port="${1:-}"
  [[ -z "$port" ]] && return 1
  ss -ltn "( sport = :$port )" 2>/dev/null | grep -q "LISTEN"
}

choose_free_socks_port() {
  local start_port="${1:-11080}"
  local end_port="${2:-11180}"
  local p
  for ((p=start_port; p<=end_port; p++)); do
    if ! is_port_busy "$p"; then
      echo "$p"
      return 0
    fi
  done
  return 1
}

refresh_socks_port_from_upstream_env() {
  if [[ ! -f "$UPSTREAM_ENV_FILE" ]]; then
    return 0
  fi
  # shellcheck disable=SC1090
  source "$UPSTREAM_ENV_FILE"
  if [[ -z "${CHIMERA_UPSTREAM_USER:-}" || -z "${CHIMERA_UPSTREAM_HOST:-}" ]]; then
    return 0
  fi
  local detected_port=""
  detected_port="$(find_matching_tunnel_port "${CHIMERA_UPSTREAM_HOST}" "${CHIMERA_UPSTREAM_USER}" || true)"
  if [[ -n "$detected_port" ]]; then
    SOCKS_PORT="$detected_port"
  fi
}

usage() {
  cat <<'EOF'
Usage: chimera-control.sh <command>

Commands:
  start          Start CHIMERA gateway+client services (systemd --user)
  stop           Stop CHIMERA gateway+client services
  restart        Restart CHIMERA services
  status         Show status for CHIMERA services and runtime state
  doctor         Run client doctor check
  logs           Tail gateway+client logs
  proxy-status   Show SOCKS tunnel and desktop proxy status
  app-routes-status  Show parsed app/service routing config
  route-status       Show split routing runtime status
  run-app <app_id> [args...]
                Run selected app through CHIMERA proxy env only
  service-proxy-enable [service...]
                Enable CHIMERA proxy env for selected user services
  service-proxy-disable [service...]
                Disable CHIMERA proxy env override for selected user services
  route-mode [show|full|split|off]
                Set/get CHIMERA routing mode
  split-list-mode [show|allow|deny]
                Set/get split domain list mode:
                allow = only listed domains go through CHIMERA
                deny  = listed domains go direct, all others through CHIMERA
  site-add <domain...>
                Add site domains to CHIMERA split list and apply
  site-remove <domain...>
                Remove site domains from CHIMERA split list and apply
  site-list     Show CHIMERA split site list
  site-auto-resolve <domain...>
                Auto-pick working path for domains and persist decision
  site-auto-status
                Show learned adaptive site decisions
  site-auto-watch [start|stop|status|run-once]
                Background adaptive recheck and auto re-pick
  upstream-probe
                Show candidate upstream endpoints and measured connect latency
  upstream-reset
                Clear upstream sticky/health state and force fresh endpoint choice
  upstream-audit [lines]
                Show upstream health snapshot + recent watchdog switch history
  upstream-failover-smoke [wait_sec]
                Force local tunnel drop and print recovery audit
  apps-running  Show running applications (process names)
  services-running
                Show running user services
  app-route-add <app_id> <command>
                Add/update app route entry in config
  app-route-add-running <process_name...>
                Add running processes as app routes automatically
  service-proxy-enable-running [service...]
                Enable CHIMERA proxy for running user services
  uninstall      Full uninstall + OS/network settings cleanup (best-effort, idempotent)
  ui-mode        Show or set UI mode override: auto|tray|dialog|cli
EOF
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "error: required command not found: $1" >&2
    exit 1
  }
}

ensure_base_path() {
  export PATH="$HOME/.cargo/bin:$PATH"
}

run_chimera_cli() {
  if [[ -x "$CHIMERA_RUNNER" ]]; then
    "$CHIMERA_RUNNER" cli "$@"
    return $?
  fi
  if [[ -x "$CHIMERA_CLI_BIN" ]]; then
    if "$CHIMERA_CLI_BIN" "$@"; then
      return 0
    fi
    if command -v cargo >/dev/null 2>&1; then
      (
        cd "$ROOT_DIR"
        cargo run -q -p chimera-cli -- "$@"
      )
      return $?
    fi
    return 1
  fi
  if command -v cargo >/dev/null 2>&1; then
    (
      cd "$ROOT_DIR"
      cargo run -q -p chimera-cli -- "$@"
    )
    return $?
  fi
  echo "error: chimera-cli binary is missing and cargo is unavailable" >&2
  return 1
}

run_chimera_gateway() {
  if [[ -x "$CHIMERA_RUNNER" ]]; then
    "$CHIMERA_RUNNER" gateway "$@"
    return $?
  fi
  if [[ -x "$CHIMERA_GATEWAY_BIN" ]]; then
    if "$CHIMERA_GATEWAY_BIN" "$@"; then
      return 0
    fi
    if command -v cargo >/dev/null 2>&1; then
      (
        cd "$ROOT_DIR"
        cargo run -q -p chimera-gateway -- "$@"
      )
      return $?
    fi
    return 1
  fi
  if command -v cargo >/dev/null 2>&1; then
    (
      cd "$ROOT_DIR"
      cargo run -q -p chimera-gateway -- "$@"
    )
    return $?
  fi
  echo "error: chimera-gateway binary is missing and cargo is unavailable" >&2
  return 1
}

systemd_user_ready() {
  command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1
}

systemd_units_active_ok() {
  local gateway_state client_state
  gateway_state="$(systemctl --user is-active chimera-gateway.service 2>/dev/null || true)"
  client_state="$(systemctl --user is-active chimera-client.service 2>/dev/null || true)"
  [[ "$gateway_state" == "active" && "$client_state" == "active" ]]
}

desktop_proxy_supported() {
  if ! command -v gsettings >/dev/null 2>&1; then
    return 1
  fi
  gsettings list-schemas 2>/dev/null | grep -qx 'org.gnome.system.proxy'
}

proxy_env_url() {
  local runtime_port="$SOCKS_PORT"
  if [[ -f "$UPSTREAM_ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_ENV_FILE"
    if [[ -n "${CHIMERA_UPSTREAM_HOST:-}" && -n "${CHIMERA_UPSTREAM_USER:-}" ]]; then
      local detected_port=""
      detected_port="$(find_matching_tunnel_port "${CHIMERA_UPSTREAM_HOST}" "${CHIMERA_UPSTREAM_USER}" || true)"
      if [[ -n "$detected_port" ]]; then
        runtime_port="$detected_port"
      fi
    fi
  fi
  echo "socks5h://$SOCKS_HOST:$runtime_port"
}

read_route_mode() {
  if [[ -f "$ROUTE_MODE_FILE" ]]; then
    local mode
    mode="$(tr -d '[:space:]' < "$ROUTE_MODE_FILE" | tr '[:upper:]' '[:lower:]')"
    case "$mode" in
      full|split|off) echo "$mode"; return 0 ;;
      selective) echo "split"; return 0 ;;
    esac
  fi
  echo "split"
}

write_route_mode() {
  local mode="${1:-split}"
  if [[ "$mode" == "selective" ]]; then
    mode="split"
  fi
  mkdir -p "$(dirname "$ROUTE_MODE_FILE")"
  printf '%s\n' "$mode" > "$ROUTE_MODE_FILE"
}

read_split_list_mode() {
  if [[ -f "$SPLIT_LIST_MODE_FILE" ]]; then
    local mode
    mode="$(tr -d '[:space:]' < "$SPLIT_LIST_MODE_FILE" | tr '[:upper:]' '[:lower:]')"
    case "$mode" in
      allow|deny) echo "$mode"; return 0 ;;
    esac
  fi
  echo "allow"
}

write_split_list_mode() {
  local mode="${1:-allow}"
  case "$mode" in
    allow|deny) ;;
    *) mode="allow" ;;
  esac
  mkdir -p "$(dirname "$SPLIT_LIST_MODE_FILE")"
  printf '%s\n' "$mode" > "$SPLIT_LIST_MODE_FILE"
}

trim_ascii() {
  local s="${1:-}"
  s="${s#"${s%%[![:space:]]*}"}"
  s="${s%"${s##*[![:space:]]}"}"
  printf '%s' "$s"
}

split_csv_lines() {
  local csv="${1:-}"
  IFS=',' read -r -a out <<<"$csv"
  local item
  for item in "${out[@]}"; do
    item="$(trim_ascii "$item")"
    [[ -z "$item" ]] && continue
    printf '%s\n' "$item"
  done
}

proxy_healthcheck_ok() {
  env -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY -u http_proxy -u https_proxy -u all_proxy \
    curl -sS \
      --proxy "socks5h://$SOCKS_HOST:$SOCKS_PORT" \
      --connect-timeout "$SOCKS_HEALTHCHECK_TIMEOUT_SEC" \
      --max-time "$SOCKS_HEALTHCHECK_TIMEOUT_SEC" \
      "$SOCKS_HEALTHCHECK_URL" >/dev/null 2>&1
}

build_upstream_candidates() {
  local out=()
  if [[ -n "${CHIMERA_UPSTREAM_TRANSPORTS_CSV:-}" ]]; then
    local entry
    while IFS= read -r entry; do
      [[ -z "$entry" ]] && continue
      out+=("$entry")
    done < <(split_csv_lines "$CHIMERA_UPSTREAM_TRANSPORTS_CSV")
  fi
  if [[ -n "${CHIMERA_UPSTREAM_ENDPOINTS_CSV:-}" ]]; then
    local entry
    while IFS= read -r entry; do
      [[ -z "$entry" ]] && continue
      out+=("$entry")
    done < <(split_csv_lines "$CHIMERA_UPSTREAM_ENDPOINTS_CSV")
  fi
  if [[ "${#out[@]}" -eq 0 && -n "${CHIMERA_UPSTREAM_HOST:-}" ]]; then
    out+=("${CHIMERA_UPSTREAM_HOST}:${CHIMERA_UPSTREAM_PORT:-22}")
  fi
  printf '%s\n' "${out[@]}"
}

count_upstream_candidates() {
  local n=0 line
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    n=$((n + 1))
  done < <(build_upstream_candidates)
  echo "$n"
}

parse_transport_endpoint() {
  local candidate="${1:-}"
  local transport="ssh"
  local endpoint="$candidate"
  if [[ "$candidate" == *@* ]]; then
    transport="${candidate%%@*}"
    endpoint="${candidate#*@}"
  fi
  transport="$(trim_ascii "${transport,,}")"
  endpoint="$(trim_ascii "$endpoint")"
  if [[ -z "$endpoint" ]]; then
    return 1
  fi
  local host="${endpoint%:*}"
  local port="${endpoint##*:}"
  if [[ "$host" == "$port" ]]; then
    case "$transport" in
      ssh443|ssh-443|tls|tcp443) port="443" ;;
      ssh8443|ssh-8443|tcp8443) port="8443" ;;
      *) port="${CHIMERA_UPSTREAM_PORT:-22}" ;;
    esac
    endpoint="${host}:${port}"
  fi
  printf '%s|%s\n' "$transport" "$endpoint"
}

endpoint_latency_ms_probe() {
  local parsed endpoint
  parsed="$(parse_transport_endpoint "${1:-}" || true)"
  endpoint="${parsed#*|}"
  local host="${endpoint%:*}"
  local port="${endpoint##*:}"
  [[ -z "$host" || -z "$port" ]] && echo 2147483647 && return 0
  local start end
  start="$(date +%s 2>/dev/null || echo 0)"
  if timeout 2 bash -lc "</dev/tcp/$host/$port" >/dev/null 2>&1; then
    end="$(date +%s 2>/dev/null || echo 0)"
    if [[ "$start" =~ ^[0-9]+$ && "$end" =~ ^[0-9]+$ && "$end" -ge "$start" ]]; then
      echo $(((end - start) * 1000))
    else
      echo 1
    fi
  else
    echo 2147483647
  fi
}

upstream_probe() {
  if [[ -f "$UPSTREAM_ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_ENV_FILE"
  fi
  local endpoint lat parsed transport endpoint_only
  local best="" best_lat=2147483647
  while IFS= read -r endpoint; do
    [[ -z "$endpoint" ]] && continue
    parsed="$(parse_transport_endpoint "$endpoint" || true)"
    transport="${parsed%%|*}"
    endpoint_only="${parsed#*|}"
    lat="$(endpoint_latency_ms_probe "$endpoint")"
    echo "upstream_candidate transport=${transport:-unknown} endpoint=${endpoint_only:-unknown} latency_ms=$lat"
    if [[ "$lat" =~ ^[0-9]+$ ]] && [[ "$lat" -lt "$best_lat" ]]; then
      best_lat="$lat"
      best="$endpoint_only"
    fi
  done < <(build_upstream_candidates)
  if [[ -n "$best" ]]; then
    echo "upstream_best endpoint=$best latency_ms=$best_lat strategy=$UPSTREAM_STRATEGY"
  else
    echo "upstream_best endpoint=none"
  fi
}

upstream_reset() {
  rm -f "$LAST_ENDPOINT_FILE" "$UPSTREAM_HEALTH_STATE_FILE"
  echo "upstream_state_reset=ok"
}

upstream_audit() {
  local lines="${1:-30}"
  if ! [[ "$lines" =~ ^[0-9]+$ ]]; then
    lines=30
  fi
  if [[ -f "$UPSTREAM_ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_ENV_FILE"
  fi
  echo "upstream_audit_begin"
  echo "upstream_strategy=$UPSTREAM_STRATEGY"
  local candidates_total
  candidates_total="$(count_upstream_candidates)"
  echo "upstream_candidates_total=$candidates_total"
  if [[ "$candidates_total" =~ ^[0-9]+$ ]] && [[ "$candidates_total" -ge 2 ]]; then
    echo "upstream_adaptation_possible=true"
  else
    echo "upstream_adaptation_possible=false"
  fi
  if [[ -f "$LAST_ENDPOINT_FILE" ]]; then
    echo "upstream_last_endpoint=$(awk -F'|' 'NR==1{print $1}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
    echo "upstream_last_endpoint_sticky_until=$(awk -F'|' 'NR==1{print $2}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
  else
    echo "upstream_last_endpoint=unknown"
  fi
  if [[ -f "$UPSTREAM_HEALTH_STATE_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_HEALTH_STATE_FILE"
    echo "upstream_health_listener_up=${listener_up:-unknown}"
    echo "upstream_health_ok=${health_ok:-unknown}"
    echo "upstream_degrade_fails=${degrade_fails:-unknown}"
    echo "upstream_degrade_threshold=${degrade_threshold:-unknown}"
    echo "upstream_last_reason=${last_reason:-unknown}"
    echo "upstream_last_transport=${last_transport:-unknown}"
    echo "upstream_health_ts=${ts:-unknown}"
  else
    echo "upstream_health_state=missing"
  fi
  echo "upstream_probe_now:"
  upstream_probe
  if [[ -f "${XDG_CACHE_HOME:-$HOME/.cache}/chimera/socks-watchdog.log" ]]; then
    echo "upstream_recent_events:"
    tail -n "$lines" "${XDG_CACHE_HOME:-$HOME/.cache}/chimera/socks-watchdog.log" | grep -E 'endpoint_probe|failover|reason=' || true
  fi
  echo "upstream_audit_end"
}

upstream_failover_smoke() {
  local wait_sec="${1:-10}"
  if ! [[ "$wait_sec" =~ ^[0-9]+$ ]]; then
    wait_sec=10
  fi
  start_socks_watchdog || true
  local before="down"
  local after="down"
  if ss -ltn "( sport = :$SOCKS_PORT )" 2>/dev/null | grep -q "$SOCKS_HOST:$SOCKS_PORT"; then
    before="up"
  fi
  pkill -f "ssh .* -D $SOCKS_HOST:$SOCKS_PORT .*@.*" 2>/dev/null || true
  pkill -f "ssh .* -D $SOCKS_PORT .*@.*" 2>/dev/null || true
  sleep 1
  if ss -ltn "( sport = :$SOCKS_PORT )" 2>/dev/null | grep -q "$SOCKS_HOST:$SOCKS_PORT"; then
    after="up"
  fi
  echo "upstream_failover_smoke_drop before=$before after=$after"
  sleep "$wait_sec"
  upstream_audit 200
}

launch_socks_tunnel_for_endpoint() {
  local parsed transport endpoint
  parsed="$(parse_transport_endpoint "${1:-}" || true)"
  transport="${parsed%%|*}"
  endpoint="${parsed#*|}"
  [[ -z "$endpoint" ]] && return 1
  local host="${endpoint%:*}"
  local port="${endpoint##*:}"
  [[ -z "$host" || -z "$port" ]] && return 1
  [[ "$port" =~ ^[0-9]+$ ]] || return 1
  case "$transport" in
    ""|ssh|ssh22|ssh-22|ssh443|ssh-443|ssh8443|ssh-8443|tls|tcp443|tcp8443) ;;
    *)
      echo "upstream_skip transport=$transport reason=unsupported"
      return 1
      ;;
  esac
  SSHPASS="$CHIMERA_UPSTREAM_PASS" nohup sshpass -e ssh \
    -o StrictHostKeyChecking=no \
    -o ExitOnForwardFailure=yes \
    -o ServerAliveInterval=30 \
    -o ServerAliveCountMax=3 \
    -N -D "$SOCKS_HOST:$SOCKS_PORT" \
    -p "$port" \
      "$CHIMERA_UPSTREAM_USER@$host" >/dev/null 2>&1 &
  local ssh_pid=$!
  for _ in 1 2 3 4 5 6; do
    sleep 1
    if ss -ltn "( sport = :$SOCKS_PORT )" 2>/dev/null | grep -q "$SOCKS_HOST:$SOCKS_PORT"; then
      if proxy_healthcheck_ok; then
        return 0
      fi
      kill "$ssh_pid" 2>/dev/null || true
      pkill -f "ssh .* -D $SOCKS_HOST:$SOCKS_PORT .*@.*" 2>/dev/null || true
      return 1
    fi
  done
  kill "$ssh_pid" 2>/dev/null || true
  return 1
}

parse_env_pairs() {
  local raw="${1:-}"
  local out=()
  local pair trimmed
  IFS=';' read -r -a out <<<"$raw"
  for pair in "${out[@]}"; do
    trimmed="$(trim_ascii "$pair")"
    [[ -z "$trimmed" ]] && continue
    if [[ "$trimmed" != *=* ]]; then
      continue
    fi
    printf '%s\n' "$trimmed"
  done
}

service_override_dir() {
  local svc="${1:?service_name_required}"
  echo "${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/${svc}.d"
}

service_override_file() {
  local svc="${1:?service_name_required}"
  echo "$(service_override_dir "$svc")/90-chimera-proxy.conf"
}

parse_app_routes_file() {
  local line key value
  [[ -f "$APP_ROUTES_FILE" ]] || return 0
  while IFS= read -r line; do
    line="${line%%#*}"
    line="$(trim_ascii "$line")"
    [[ -z "$line" ]] && continue
    key="${line%%=*}"
    value="${line#*=}"
    key="$(trim_ascii "$key")"
    value="$(trim_ascii "$value")"
    if [[ -z "$key" || -z "$value" ]]; then
      continue
    fi
    case "$key" in
      app:*)
        local app_id="${key#app:}"
        APP_ROUTE_IDS+=("$app_id")
        APP_ROUTE_CMDS["$app_id"]="$value"
        ;;
      app-env:*)
        local app_env_id="${key#app-env:}"
        APP_ROUTE_ENV["$app_env_id"]="$value"
        ;;
      service:*)
        local svc_id="${key#service:}"
        SERVICE_ROUTE_IDS+=("$svc_id")
        SERVICE_ROUTE_NAMES["$svc_id"]="$value"
        ;;
      service-env:*)
        local svc_env_id="${key#service-env:}"
        SERVICE_ROUTE_ENV["$svc_env_id"]="$value"
        ;;
      *)
        ;;
    esac
  done <"$APP_ROUTES_FILE"
}

upsert_route_line() {
  local file="$1"
  local key="$2"
  local value="$3"
  mkdir -p "$(dirname "$file")"
  touch "$file"
  local esc_key esc_val
  esc_key="$(printf '%s' "$key" | sed 's/[^^]/[&]/g; s/\^/\\^/g')"
  esc_val="$(printf '%s' "$value" | sed 's/[&/\]/\\&/g')"
  if rg -n "^${esc_key}=" "$file" >/dev/null 2>&1; then
    sed -i "s/^${esc_key}=.*/${key}=${esc_val}/" "$file"
  else
    printf '%s=%s\n' "$key" "$value" >> "$file"
  fi
}

normalize_app_id() {
  local raw="${1:-}"
  raw="$(trim_ascii "$raw")"
  raw="${raw,,}"
  raw="$(printf '%s' "$raw" | sed 's/[^a-z0-9._-]/_/g')"
  raw="${raw##_}"
  raw="${raw%%_}"
  printf '%s' "$raw"
}

print_app_routes_status() {
  echo "app_routes_file=$APP_ROUTES_FILE"
  if [[ ! -f "$APP_ROUTES_FILE" ]]; then
    echo "app_routes_config=missing"
    return 0
  fi
  parse_app_routes_file
  echo "app_routes_count=${#APP_ROUTE_IDS[@]}"
  for id in "${APP_ROUTE_IDS[@]}"; do
    echo "app_route[$id]=${APP_ROUTE_CMDS[$id]}"
    if [[ -n "${APP_ROUTE_ENV[$id]:-}" ]]; then
      echo "app_route_env[$id]=${APP_ROUTE_ENV[$id]}"
    fi
  done
  echo "service_routes_count=${#SERVICE_ROUTE_IDS[@]}"
  for id in "${SERVICE_ROUTE_IDS[@]}"; do
    echo "service_route[$id]=${SERVICE_ROUTE_NAMES[$id]}"
    if [[ -n "${SERVICE_ROUTE_ENV[$id]:-}" ]]; then
      echo "service_route_env[$id]=${SERVICE_ROUTE_ENV[$id]}"
    fi
    if [[ -f "$(service_override_file "${SERVICE_ROUTE_NAMES[$id]}")" ]]; then
      echo "service_route_override[$id]=enabled"
    else
      echo "service_route_override[$id]=disabled"
    fi
  done
}

run_app_via_proxy() {
  local app_id="${1:-}"
  shift || true
  if [[ -z "$app_id" ]]; then
    echo "error: run-app requires <app_id>" >&2
    exit 1
  fi
  parse_app_routes_file
  local cmd="${APP_ROUTE_CMDS[$app_id]:-}"
  if [[ -z "$cmd" ]]; then
    echo "error: app route not found for id: $app_id" >&2
    exit 1
  fi
  local proxy_url
  proxy_url="$(proxy_env_url)"
  echo "run-app: id=$app_id cmd=$cmd proxy=$proxy_url"
  local full_cmd="$cmd"
  if [[ "$#" -gt 0 ]]; then
    local arg
    for arg in "$@"; do
      full_cmd+=" $(printf '%q' "$arg")"
    done
  fi
  local env_pairs=()
  local pair
  while IFS= read -r pair; do
    env_pairs+=("$pair")
  done < <(parse_env_pairs "${APP_ROUTE_ENV[$app_id]:-}")
  env -u CURL_CA_BUNDLE -u SSL_CERT_FILE \
    "HTTP_PROXY=$proxy_url" \
    "HTTPS_PROXY=$proxy_url" \
    "ALL_PROXY=$proxy_url" \
    "NO_PROXY=localhost,127.0.0.1,::1" \
    "http_proxy=$proxy_url" \
    "https_proxy=$proxy_url" \
    "all_proxy=$proxy_url" \
    "no_proxy=localhost,127.0.0.1,::1" \
    "${env_pairs[@]}" \
    bash -lc "$full_cmd"
}

service_proxy_enable() {
  parse_app_routes_file
  local proxy_url
  proxy_url="$(proxy_env_url)"
  local services=("$@")
  if [[ "${#services[@]}" -eq 0 ]]; then
    services=("${SERVICE_ROUTE_NAMES[@]}")
  else
    local resolved=()
    local svc
    for svc in "${services[@]}"; do
      if [[ -n "${SERVICE_ROUTE_NAMES[$svc]:-}" ]]; then
        resolved+=("${SERVICE_ROUTE_NAMES[$svc]}")
      else
        resolved+=("$svc")
      fi
    done
    services=("${resolved[@]}")
  fi
  if [[ "${#services[@]}" -eq 0 ]]; then
    echo "service-proxy-enable: no services configured"
    return 0
  fi
  require_cmd systemctl
  for svc in "${services[@]}"; do
    local matched_id=""
    local id
    for id in "${SERVICE_ROUTE_IDS[@]}"; do
      if [[ "${SERVICE_ROUTE_NAMES[$id]}" == "$svc" ]]; then
        matched_id="$id"
        break
      fi
    done
    local override
    override="$(service_override_file "$svc")"
    mkdir -p "$(dirname "$override")"
    {
      echo "[Service]"
      echo "Environment=HTTP_PROXY=$proxy_url"
      echo "Environment=HTTPS_PROXY=$proxy_url"
      echo "Environment=ALL_PROXY=$proxy_url"
      echo "Environment=NO_PROXY=localhost,127.0.0.1,::1"
      echo "Environment=http_proxy=$proxy_url"
      echo "Environment=https_proxy=$proxy_url"
      echo "Environment=all_proxy=$proxy_url"
      echo "Environment=no_proxy=localhost,127.0.0.1,::1"
      if [[ -n "$matched_id" && -n "${SERVICE_ROUTE_ENV[$matched_id]:-}" ]]; then
        local pair
        while IFS= read -r pair; do
          echo "Environment=$pair"
        done < <(parse_env_pairs "${SERVICE_ROUTE_ENV[$matched_id]}")
      fi
    } >"$override"
    systemctl --user daemon-reload
    systemctl --user restart "$svc" || true
    echo "service_proxy_enabled=$svc proxy=$proxy_url override=$override"
  done
}

service_proxy_disable() {
  parse_app_routes_file
  local services=("$@")
  if [[ "${#services[@]}" -eq 0 ]]; then
    services=("${SERVICE_ROUTE_NAMES[@]}")
  else
    local resolved=()
    local svc
    for svc in "${services[@]}"; do
      if [[ -n "${SERVICE_ROUTE_NAMES[$svc]:-}" ]]; then
        resolved+=("${SERVICE_ROUTE_NAMES[$svc]}")
      else
        resolved+=("$svc")
      fi
    done
    services=("${resolved[@]}")
  fi
  if [[ "${#services[@]}" -eq 0 ]]; then
    echo "service-proxy-disable: no services configured"
    return 0
  fi
  require_cmd systemctl
  for svc in "${services[@]}"; do
    local override
    override="$(service_override_file "$svc")"
    rm -f "$override"
    rmdir "$(dirname "$override")" 2>/dev/null || true
    systemctl --user daemon-reload
    systemctl --user restart "$svc" || true
    echo "service_proxy_disabled=$svc override_removed=$override"
  done
}

print_route_status() {
  refresh_socks_port_from_upstream_env
  local proxy_url
  proxy_url="$(proxy_env_url)"
  echo "chimera_proxy_url=$proxy_url"
  echo "route_mode=$(read_route_mode)"
  echo "split_list_mode=$(read_split_list_mode)"
  if ss -ltn "( sport = :$SOCKS_PORT )" 2>/dev/null | grep -q "$SOCKS_HOST:$SOCKS_PORT"; then
    echo "chimera_proxy_listener=up"
  else
    echo "chimera_proxy_listener=down"
  fi
  echo "upstream_strategy=$UPSTREAM_STRATEGY"
  echo "upstream_sticky_sec=$UPSTREAM_STICKY_SEC"
  if [[ -f "$LAST_ENDPOINT_FILE" ]]; then
    echo "upstream_last_endpoint=$(awk -F'|' 'NR==1{print $1}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
    echo "upstream_last_endpoint_sticky_until=$(awk -F'|' 'NR==1{print $2}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
  else
    echo "upstream_last_endpoint=unknown"
  fi
  if [[ -f "$UPSTREAM_HEALTH_STATE_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$UPSTREAM_HEALTH_STATE_FILE"
    echo "upstream_health_listener_up=${listener_up:-unknown}"
    echo "upstream_health_ok=${health_ok:-unknown}"
    echo "upstream_degrade_fails=${degrade_fails:-unknown}"
    echo "upstream_degrade_threshold=${degrade_threshold:-unknown}"
    echo "upstream_last_reason=${last_reason:-unknown}"
    echo "upstream_last_transport=${last_transport:-unknown}"
    echo "upstream_health_ts=${ts:-unknown}"
  else
    echo "upstream_health_state=missing"
  fi
  print_app_routes_status
}

apply_desktop_proxy() {
  local mode="$1"
  if ! desktop_proxy_supported; then
    return 0
  fi
  if [[ "$mode" == "manual" ]]; then
    gsettings set org.gnome.system.proxy mode 'manual' 2>/dev/null || true
    gsettings set org.gnome.system.proxy.socks host "$SOCKS_HOST" 2>/dev/null || true
    gsettings set org.gnome.system.proxy.socks port "$SOCKS_PORT" 2>/dev/null || true
  elif [[ "$mode" == "auto" ]]; then
    gsettings set org.gnome.system.proxy mode 'auto' 2>/dev/null || true
    gsettings set org.gnome.system.proxy autoconfig-url "file://$PAC_FILE" 2>/dev/null || true
  else
    gsettings set org.gnome.system.proxy mode 'none' 2>/dev/null || true
  fi
}

apply_route_mode() {
  local mode
  mode="$(read_route_mode)"
  case "$mode" in
    full)
      apply_desktop_proxy manual
      ;;
    split)
      build_pac_file
      apply_desktop_proxy auto
      ;;
    off)
      apply_desktop_proxy none
      ;;
    *)
      apply_desktop_proxy auto
      ;;
  esac
}

auto_sync_desktop_proxy_port() {
  refresh_socks_port_from_upstream_env
  if [[ "$PROXY_AUTOSYNC" != "1" ]]; then
    return 0
  fi
  if ! desktop_proxy_supported; then
    return 0
  fi

  local mode host port
  mode="$(gsettings get org.gnome.system.proxy mode 2>/dev/null || echo "'unknown'")"
  host="$(gsettings get org.gnome.system.proxy.socks host 2>/dev/null || echo "'unknown'")"
  port="$(gsettings get org.gnome.system.proxy.socks port 2>/dev/null || echo "0")"
  host="${host//\'}"

  if [[ "$mode" == "'manual'" ]]; then
    if [[ "$host" != "$SOCKS_HOST" ]] || [[ "$port" != "$SOCKS_PORT" ]]; then
      gsettings set org.gnome.system.proxy.socks host "$SOCKS_HOST" || true
      gsettings set org.gnome.system.proxy.socks port "$SOCKS_PORT" || true
      echo "chimera_proxy_autosync=applied mode=manual host=$SOCKS_HOST port=$SOCKS_PORT"
    fi
  elif [[ "$mode" == "'auto'" ]]; then
    # Keep PAC mode, but make SOCKS tuple consistent for apps that still read socks settings.
    if [[ "$host" != "$SOCKS_HOST" ]] || [[ "$port" != "$SOCKS_PORT" ]]; then
      gsettings set org.gnome.system.proxy.socks host "$SOCKS_HOST" || true
      gsettings set org.gnome.system.proxy.socks port "$SOCKS_PORT" || true
      echo "chimera_proxy_autosync=applied mode=auto host=$SOCKS_HOST port=$SOCKS_PORT"
    fi
  fi
}

build_pac_file() {
  mkdir -p "$(dirname "$PAC_FILE")"
  local tmp_pac
  tmp_pac="$(mktemp)"
  local mode
  mode="$(read_route_mode)"
  local split_mode
  split_mode="$(read_split_list_mode)"
  local has_manual_domains=false
  if [[ -f "$MANUAL_GATEWAY_DOMAINS_FILE" ]] && rg -n '^[[:space:]]*[^#[:space:]].*$' "$MANUAL_GATEWAY_DOMAINS_FILE" >/dev/null 2>&1; then
    has_manual_domains=true
  fi
  {
    echo "function FindProxyForURL(url, host) {"
    echo "  var h = host.toLowerCase();"
    echo "  function m(s) { return dnsDomainIs(h, \".\" + s) || h == s; }"
    if [[ "$mode" == "full" ]]; then
      echo "  return \"SOCKS5 $SOCKS_HOST:$SOCKS_PORT\";"
      echo "}"
      mv "$tmp_pac" "$PAC_FILE"
      return 0
    fi

    # Split mode: domain list controls direction with allow/deny policy.
    if [[ "$mode" == "split" ]]; then
      if [[ "$has_manual_domains" == true ]]; then
        while IFS= read -r raw; do
          local_domain="$(echo "$raw" | tr -d '[:space:]')"
          [[ -z "$local_domain" ]] && continue
          [[ "$local_domain" == \#* ]] && continue
          local_domain="${local_domain#.}"
          if [[ "$split_mode" == "allow" ]]; then
            echo "  if (m(\"$local_domain\")) return \"SOCKS5 $SOCKS_HOST:$SOCKS_PORT\";"
          else
            echo "  if (m(\"$local_domain\")) return \"DIRECT\";"
          fi
        done <"$MANUAL_GATEWAY_DOMAINS_FILE"
      fi
      if [[ "$split_mode" == "allow" ]]; then
        echo "  return \"DIRECT\";"
      else
        echo "  return \"SOCKS5 $SOCKS_HOST:$SOCKS_PORT\";"
      fi
      echo "}"
      mv "$tmp_pac" "$PAC_FILE"
      return 0
    fi

    if [[ -f "$POLICY_FILE" ]]; then
      awk -F'suffix:| => ' '/suffix:.*=> gateway/ {print $2}' "$POLICY_FILE" | while IFS= read -r suffix; do
        suffix="$(echo "$suffix" | xargs)"
        [[ -z "$suffix" ]] && continue
        suffix="${suffix#.}"
        echo "  if (m(\"$suffix\")) return \"SOCKS5 $SOCKS_HOST:$SOCKS_PORT\";"
      done
    fi
    if [[ -f "$MANUAL_GATEWAY_DOMAINS_FILE" ]]; then
      while IFS= read -r raw; do
        domain="$(echo "$raw" | tr -d '[:space:]')"
        [[ -z "$domain" ]] && continue
        [[ "$domain" == \#* ]] && continue
        domain="${domain#.}"
        echo "  if (m(\"$domain\")) return \"SOCKS5 $SOCKS_HOST:$SOCKS_PORT\";"
      done <"$MANUAL_GATEWAY_DOMAINS_FILE"
    fi
    echo "  return \"DIRECT\";"
    echo "}"
  } >"$tmp_pac"
  mv "$tmp_pac" "$PAC_FILE"
}

normalize_domain() {
  local raw="${1:-}"
  raw="$(trim_ascii "$raw")"
  raw="${raw,,}"
  raw="${raw#http://}"
  raw="${raw#https://}"
  raw="${raw%%/*}"
  raw="${raw%%:*}"
  raw="${raw#.}"
  raw="${raw%.}"
  printf '%s' "$raw"
}

site_adaptive_upsert() {
  local domain="$1"
  local decision="$2"
  mkdir -p "$(dirname "$SITE_ADAPTIVE_DB_FILE")"
  touch "$SITE_ADAPTIVE_DB_FILE"
  local now
  now="$(date +%s)"
  local tmp
  tmp="$(mktemp)"
  awk -F'|' -v d="$domain" '$1 != d {print $0}' "$SITE_ADAPTIVE_DB_FILE" >"$tmp" || true
  printf '%s|%s|%s\n' "$domain" "$decision" "$now" >>"$tmp"
  mv "$tmp" "$SITE_ADAPTIVE_DB_FILE"
}

site_adaptive_status() {
  if [[ ! -f "$SITE_ADAPTIVE_DB_FILE" ]]; then
    echo "site_adaptive_db=$SITE_ADAPTIVE_DB_FILE (missing)"
    return 0
  fi
  echo "site_adaptive_db=$SITE_ADAPTIVE_DB_FILE"
  awk -F'|' 'NF>=3{printf "domain=%s decision=%s ts=%s\n",$1,$2,$3}' "$SITE_ADAPTIVE_DB_FILE"
}

site_adaptive_get_decision() {
  local domain="$1"
  [[ -f "$SITE_ADAPTIVE_DB_FILE" ]] || return 1
  awk -F'|' -v d="$domain" '$1==d{dec=$2} END{if(dec!="") print dec}' "$SITE_ADAPTIVE_DB_FILE"
}

http_code_via_path() {
  local domain="$1"
  local via="$2"
  local code=""
  local ua
  ua="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
  if [[ "$via" == "proxy" ]]; then
    code="$(curl -sS -o /dev/null -w '%{http_code}' --proxy "socks5h://$SOCKS_HOST:$SOCKS_PORT" -A "$ua" --connect-timeout 12 --max-time 25 "https://$domain" 2>/dev/null || true)"
  else
    code="$(env -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY -u http_proxy -u https_proxy -u all_proxy \
      curl -sS -o /dev/null -w '%{http_code}' -A "$ua" --connect-timeout 12 --max-time 25 "https://$domain" 2>/dev/null || true)"
  fi
  [[ -z "$code" ]] && code="000"
  echo "$code"
}

is_success_http_code() {
  local code="${1:-000}"
  [[ "$code" =~ ^2[0-9][0-9]$ || "$code" =~ ^3[0-9][0-9]$ ]]
}

apply_domain_decision_to_split_list() {
  local domain="$1"
  local decision="$2"
  local split_mode
  split_mode="$(read_split_list_mode)"
  case "$split_mode" in
    allow)
      if [[ "$decision" == "proxy" ]]; then
        site_add "$domain" >/dev/null
      else
        site_remove "$domain" >/dev/null || true
      fi
      ;;
    deny)
      if [[ "$decision" == "direct" ]]; then
        site_add "$domain" >/dev/null
      else
        site_remove "$domain" >/dev/null || true
      fi
      ;;
  esac
}

site_auto_resolve_one() {
  local domain_raw="$1"
  local domain
  domain="$(normalize_domain "$domain_raw")"
  [[ -z "$domain" ]] && return 0

  # Baseline policy in split mode: allow=>default direct, deny=>default proxy.
  local split_mode
  split_mode="$(read_split_list_mode)"
  local first second
  if [[ "$split_mode" == "allow" ]]; then
    first="direct"; second="proxy"
  else
    first="proxy"; second="direct"
  fi

  local first_code second_code decision prev_decision
  prev_decision="$(site_adaptive_get_decision "$domain" || true)"
  first_code="$(http_code_via_path "$domain" "$first")"
  if is_success_http_code "$first_code"; then
    decision="$first"
  else
    second_code="$(http_code_via_path "$domain" "$second")"
    if is_success_http_code "$second_code"; then
      decision="$second"
    else
      # If both paths failed transiently, keep last known-good decision when possible.
      if [[ "$prev_decision" == "proxy" || "$prev_decision" == "direct" ]]; then
        decision="$prev_decision"
      else
        decision="$first"
      fi
    fi
  fi

  apply_domain_decision_to_split_list "$domain" "$decision"
  site_adaptive_upsert "$domain" "$decision"
  apply_route_mode
  echo "site_auto_resolve domain=$domain first=$first code_first=${first_code:-000} second=$second code_second=${second_code:-000} decision=$decision"
}

site_auto_resolve_many() {
  if [[ "$#" -eq 0 ]]; then
    echo "error: site-auto-resolve requires at least one domain" >&2
    exit 1
  fi
  local d
  for d in "$@"; do
    site_auto_resolve_one "$d"
  done
}

site_auto_watch_run_once() {
  if [[ ! -f "$SITE_ADAPTIVE_DB_FILE" ]]; then
    echo "site_auto_watch=skip reason=no_db"
    return 0
  fi
  local domains=()
  while IFS='|' read -r d _; do
    [[ -z "$d" ]] && continue
    domains+=("$d")
  done <"$SITE_ADAPTIVE_DB_FILE"
  if [[ "${#domains[@]}" -eq 0 ]]; then
    echo "site_auto_watch=skip reason=empty_db"
    return 0
  fi
  site_auto_resolve_many "${domains[@]}"
  # Enforce persisted decisions into active split list each cycle.
  local d dec
  while IFS='|' read -r d dec _; do
    [[ -z "$d" || -z "$dec" ]] && continue
    if [[ "$dec" == "proxy" || "$dec" == "direct" ]]; then
      apply_domain_decision_to_split_list "$d" "$dec"
    fi
  done <"$SITE_ADAPTIVE_DB_FILE"
  apply_route_mode
}

site_auto_watch_start() {
  if [[ -f "$SITE_AUTOWATCH_PID_FILE" ]]; then
    local old_pid
    old_pid="$(cat "$SITE_AUTOWATCH_PID_FILE" 2>/dev/null || true)"
    if [[ -n "$old_pid" ]] && kill -0 "$old_pid" 2>/dev/null; then
      echo "site_auto_watch=already_running pid=$old_pid"
      return 0
    fi
  fi
  nohup bash -lc "
    echo \$\$ > '$SITE_AUTOWATCH_PID_FILE'
    trap 'rm -f \"$SITE_AUTOWATCH_PID_FILE\"' EXIT
    while true; do
      '$SCRIPT_PATH' site-auto-watch run-once >/dev/null 2>&1 || true
      sleep '$SITE_AUTOWATCH_INTERVAL_SEC'
    done
  " >/dev/null 2>&1 &
  echo "site_auto_watch=started interval_sec=$SITE_AUTOWATCH_INTERVAL_SEC"
}

site_auto_watch_stop() {
  if [[ -f "$SITE_AUTOWATCH_PID_FILE" ]]; then
    local pid
    pid="$(cat "$SITE_AUTOWATCH_PID_FILE" 2>/dev/null || true)"
    if [[ -n "$pid" ]]; then
      kill "$pid" 2>/dev/null || true
    fi
    rm -f "$SITE_AUTOWATCH_PID_FILE"
  fi
  echo "site_auto_watch=stopped"
}

site_auto_watch_status() {
  if [[ -f "$SITE_AUTOWATCH_PID_FILE" ]]; then
    local pid
    pid="$(cat "$SITE_AUTOWATCH_PID_FILE" 2>/dev/null || true)"
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
      echo "site_auto_watch=running pid=$pid interval_sec=$SITE_AUTOWATCH_INTERVAL_SEC"
      return 0
    fi
  fi
  echo "site_auto_watch=stopped"
}

site_list() {
  if [[ ! -f "$MANUAL_GATEWAY_DOMAINS_FILE" ]]; then
    echo "site_list_file=$MANUAL_GATEWAY_DOMAINS_FILE (missing)"
    return 0
  fi
  echo "site_list_file=$MANUAL_GATEWAY_DOMAINS_FILE"
  awk 'NF && $1 !~ /^#/{print}' "$MANUAL_GATEWAY_DOMAINS_FILE" | sed 's/[[:space:]]//g'
}

apps_running() {
  ps -eo comm= 2>/dev/null | tr -s ' ' | sed '/^$/d' | sort -u
}

services_running() {
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user list-units --type=service --state=running --no-legend --no-pager 2>/dev/null | awk '{print $1}'
  fi
}

app_route_add() {
  local app_id="${1:-}"
  shift || true
  local cmd="${*:-}"
  if [[ -z "$app_id" || -z "$cmd" ]]; then
    echo "error: app-route-add requires <app_id> <command>" >&2
    exit 1
  fi
  app_id="$(normalize_app_id "$app_id")"
  if [[ -z "$app_id" ]]; then
    echo "error: normalized app_id is empty" >&2
    exit 1
  fi
  upsert_route_line "$APP_ROUTES_FILE" "app:${app_id}" "$cmd"
  echo "app_route_added id=$app_id cmd=$cmd file=$APP_ROUTES_FILE"
}

app_route_add_running() {
  if [[ "$#" -eq 0 ]]; then
    echo "error: app-route-add-running requires at least one process_name" >&2
    exit 1
  fi
  local p id
  for p in "$@"; do
    p="$(trim_ascii "$p")"
    [[ -z "$p" ]] && continue
    id="$(normalize_app_id "$p")"
    [[ -z "$id" ]] && continue
    upsert_route_line "$APP_ROUTES_FILE" "app:${id}" "$p"
    echo "app_route_added_from_running id=$id cmd=$p"
  done
}

service_proxy_enable_running() {
  local running=()
  local svc
  while IFS= read -r svc; do
    [[ -z "$svc" ]] && continue
    running+=("$svc")
  done < <(services_running)

  if [[ "$#" -gt 0 ]]; then
    service_proxy_enable "$@"
    return 0
  fi
  if [[ "${#running[@]}" -eq 0 ]]; then
    echo "service-proxy-enable-running: no running user services"
    return 0
  fi
  service_proxy_enable "${running[@]}"
}

site_add() {
  if [[ "$#" -eq 0 ]]; then
    echo "error: site-add requires at least one domain" >&2
    exit 1
  fi
  mkdir -p "$(dirname "$MANUAL_GATEWAY_DOMAINS_FILE")"
  touch "$MANUAL_GATEWAY_DOMAINS_FILE"
  local d norm
  for d in "$@"; do
    norm="$(normalize_domain "$d")"
    [[ -z "$norm" ]] && continue
    if ! rg -n "^${norm}$" "$MANUAL_GATEWAY_DOMAINS_FILE" >/dev/null 2>&1; then
      echo "$norm" >> "$MANUAL_GATEWAY_DOMAINS_FILE"
      echo "site_added=$norm"
    fi
  done
  apply_route_mode
}

site_remove() {
  if [[ "$#" -eq 0 ]]; then
    echo "error: site-remove requires at least one domain" >&2
    exit 1
  fi
  [[ -f "$MANUAL_GATEWAY_DOMAINS_FILE" ]] || return 0
  local tmp d norm
  tmp="$(mktemp)"
  cp "$MANUAL_GATEWAY_DOMAINS_FILE" "$tmp"
  for d in "$@"; do
    norm="$(normalize_domain "$d")"
    [[ -z "$norm" ]] && continue
    sed -i "/^${norm}$/d" "$tmp"
    echo "site_removed=$norm"
  done
  mv "$tmp" "$MANUAL_GATEWAY_DOMAINS_FILE"
  apply_route_mode
}

start_socks_tunnel() {
  if [[ ! -f "$UPSTREAM_ENV_FILE" ]]; then
    return 0
  fi
  # shellcheck disable=SC1090
  source "$UPSTREAM_ENV_FILE"
  if [[ -z "${CHIMERA_UPSTREAM_USER:-}" || -z "${CHIMERA_UPSTREAM_HOST:-}" || -z "${CHIMERA_UPSTREAM_PASS:-}" ]]; then
    return 0
  fi
  local detected_port=""
  detected_port="$(find_matching_tunnel_port "${CHIMERA_UPSTREAM_HOST}" "${CHIMERA_UPSTREAM_USER}" || true)"
  if [[ -n "$detected_port" ]]; then
    SOCKS_PORT="$detected_port"
  fi
  if ss -ltn "( sport = :$SOCKS_PORT )" 2>/dev/null | grep -q "$SOCKS_HOST:$SOCKS_PORT"; then
    if proxy_healthcheck_ok; then
      build_pac_file
      apply_desktop_proxy auto
      return 0
    fi
    pkill -f "ssh .* -D $SOCKS_HOST:$SOCKS_PORT .*@.*" 2>/dev/null || true
  fi
  if ! command -v sshpass >/dev/null 2>&1; then
    return 0
  fi
  if is_port_busy "$SOCKS_PORT"; then
    local dynamic_port=""
    dynamic_port="$(choose_free_socks_port 11080 11180 || true)"
    if [[ -n "$dynamic_port" ]]; then
      SOCKS_PORT="$dynamic_port"
    fi
  fi
  local endpoint
  while IFS= read -r endpoint; do
    [[ -z "$endpoint" ]] && continue
    if launch_socks_tunnel_for_endpoint "$endpoint"; then
      build_pac_file
      apply_desktop_proxy auto
      return 0
    fi
  done < <(build_upstream_candidates)
  # Tunnel didn't come up; avoid leaving desktop in broken proxy mode.
  apply_desktop_proxy none
}

start_socks_watchdog() {
  if [[ ! -x "$WATCHDOG_SCRIPT" ]]; then
    return 0
  fi
  watchdog_pid_belongs() {
    local pid="${1:-}"
    [[ -n "$pid" ]] || return 1
    [[ -r "/proc/$pid/cmdline" ]] || return 1
    tr '\0' ' ' <"/proc/$pid/cmdline" | rg -q "chimera-socks-watchdog\\.sh"
  }
  if [[ -f "$WATCHDOG_PID_FILE" ]]; then
    local wpid
    wpid="$(cat "$WATCHDOG_PID_FILE" 2>/dev/null || true)"
    if [[ -n "$wpid" ]] && kill -0 "$wpid" 2>/dev/null; then
      if watchdog_pid_belongs "$wpid"; then
        return 0
      fi
      rm -f "$WATCHDOG_PID_FILE"
    fi
  fi
  export SOCKS_HOST SOCKS_PORT
  nohup "$WATCHDOG_SCRIPT" >/dev/null 2>&1 &
}

restart_chromium_with_pac() {
  if [[ "$AUTO_RESTART_CHROMIUM" != "1" ]]; then
    return 0
  fi
  local chromium_bin="/usr/lib64/chromium/chromium"
  if [[ ! -x "$chromium_bin" ]]; then
    return 0
  fi
  if ! pgrep -f "$chromium_bin" >/dev/null 2>&1; then
    return 0
  fi
  pkill -f "$chromium_bin" 2>/dev/null || true
  sleep 1
  DISPLAY="${DISPLAY:-:0}" WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-wayland-0}" XDG_SESSION_TYPE="${XDG_SESSION_TYPE:-wayland}" \
    nohup "$chromium_bin" \
      --ozone-platform=wayland \
      --proxy-pac-url="file://$PAC_FILE" \
      --no-default-browser-check >/dev/null 2>&1 &
}

stop_socks_tunnel() {
  if [[ -f "$WATCHDOG_PID_FILE" ]]; then
    wpid="$(cat "$WATCHDOG_PID_FILE" 2>/dev/null || true)"
    if [[ -n "${wpid:-}" ]]; then
      kill "$wpid" 2>/dev/null || true
    fi
    rm -f "$WATCHDOG_PID_FILE"
  fi
  pkill -f "ssh .* -D $SOCKS_HOST:$SOCKS_PORT .*@.*" 2>/dev/null || true
  apply_desktop_proxy none
}

uninstall_full() {
  ensure_base_path

  # 1) Stop runtime pieces (best-effort).
  site_auto_watch_stop || true
  stop_socks_tunnel || true
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user disable --now chimera-client.service chimera-gateway.service 2>/dev/null || true
  fi

  # 2) Rollback runtime state if CLI state file exists.
  if [[ -f "$STATE_FILE" ]]; then
    (
      run_chimera_cli rollback recover --state-file "$STATE_FILE" >/dev/null 2>&1 || true
      run_chimera_cli down --state-file "$STATE_FILE" >/dev/null 2>&1 || true
    ) || true
  fi

  # 3) Remove proxy overrides for configured services.
  service_proxy_disable >/dev/null 2>&1 || true
  if command -v systemctl >/dev/null 2>&1; then
    rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/"*.service.d 2>/dev/null || true
    systemctl --user daemon-reload 2>/dev/null || true
  fi

  # 4) Reset desktop proxy settings.
  if desktop_proxy_supported; then
    gsettings set org.gnome.system.proxy mode 'none' 2>/dev/null || true
    gsettings set org.gnome.system.proxy autoconfig-url '' 2>/dev/null || true
  fi

  # 5) Remove installed user units/desktop entries.
  local systemd_user_dir="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
  local applications_dir="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
  rm -f "$systemd_user_dir/chimera-gateway.service" "$systemd_user_dir/chimera-client.service" 2>/dev/null || true
  rm -f "$applications_dir/chimera-control-gui.desktop" "$applications_dir/chimera-control.desktop" 2>/dev/null || true
  rm -f "$applications_dir/chromium-browser.desktop" "$applications_dir/chromium.desktop" "$applications_dir/org.chromium.Chromium.desktop" 2>/dev/null || true
  rm -f "$ROOT_DIR/scripts/chimera-chromium-launch.sh" 2>/dev/null || true
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user daemon-reload 2>/dev/null || true
  fi

  # 6) Remove CHIMERA user state/cache settings.
  rm -f "$PAC_FILE" "$UI_MODE_FILE" "$ROUTE_MODE_FILE" "$SPLIT_LIST_MODE_FILE" 2>/dev/null || true
  rm -f "$WATCHDOG_PID_FILE" "$SITE_AUTOWATCH_PID_FILE" "$LAST_ENDPOINT_FILE" "$UPSTREAM_HEALTH_STATE_FILE" 2>/dev/null || true
  rm -f "$SITE_ADAPTIVE_DB_FILE" 2>/dev/null || true
  rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/chimera" 2>/dev/null || true
  rm -rf "${XDG_CACHE_HOME:-$HOME/.cache}/chimera" 2>/dev/null || true

  # 7) Remove local runtime artifacts created by control/runtime checks.
  rm -f "$STATE_FILE" "$ROOT_DIR/docs/runtime_state_latest.json" 2>/dev/null || true
  rm -f "$ROOT_DIR/docs/CHIMERA_PATH_PROOF.json" "$ROOT_DIR/docs/CHIMERA_CHANNEL_AUDIT.json" "$ROOT_DIR/docs/CHIMERA_E2E_CHANNEL_GATE.json" 2>/dev/null || true
  rm -f "$ROOT_DIR/docs/CHIMERA_LOAD_GATE_LAPTOP.json" "$ROOT_DIR/docs/CHIMERA_FRESH_GATE_REPORT.json" 2>/dev/null || true

  echo "uninstall_status=ok"
}

cmd="${1:-}"
declare -a APP_ROUTE_IDS=()
declare -a SERVICE_ROUTE_IDS=()
declare -A APP_ROUTE_CMDS=()
declare -A SERVICE_ROUTE_NAMES=()
declare -A APP_ROUTE_ENV=()
declare -A SERVICE_ROUTE_ENV=()
case "$cmd" in
  start)
    ensure_base_path
    if systemd_user_ready; then
      systemctl --user daemon-reload
      systemctl --user enable chimera-gateway.service chimera-client.service
      if ! systemctl --user restart chimera-gateway.service chimera-client.service; then
        sleep 1
        systemctl --user start chimera-gateway.service chimera-client.service || true
      fi
      if ! systemd_units_active_ok; then
        echo "error: chimera user services failed to become active" >&2
        systemctl --user --no-pager --full status chimera-gateway.service chimera-client.service || true
        exit 1
      fi
    else
      (
        cd "$ROOT_DIR"
        run_chimera_gateway doctor --config configs/gateway.example.conf --json --out docs/gateway_doctor_latest.json
        run_chimera_cli up --state-file docs/runtime_state_latest.json
      )
    fi
    if [[ -x "$AUTOFIX_SCRIPT" ]]; then
      mkdir -p "$(dirname "$AUTOFIX_LOG_FILE")"
      if command -v timeout >/dev/null 2>&1; then
        timeout "$AUTOFIX_TIMEOUT" "$AUTOFIX_SCRIPT" >>"$AUTOFIX_LOG_FILE" 2>&1 || true
      else
        "$AUTOFIX_SCRIPT" >>"$AUTOFIX_LOG_FILE" 2>&1 || true
      fi
    fi
    start_socks_tunnel
    apply_route_mode
    auto_sync_desktop_proxy_port
    start_socks_watchdog
    if [[ "$SITE_AUTOWATCH_ENABLED" == "1" ]]; then
      site_auto_watch_start
    fi
    restart_chromium_with_pac
    ;;
  stop)
    ensure_base_path
    if systemd_user_ready; then
      systemctl --user disable --now chimera-client.service chimera-gateway.service || true
    else
      (
        cd "$ROOT_DIR"
        run_chimera_cli down --state-file docs/runtime_state_latest.json || true
      )
    fi
    site_auto_watch_stop
    stop_socks_tunnel
    ;;
  restart)
    ensure_base_path
    if systemd_user_ready; then
      systemctl --user daemon-reload
      systemctl --user restart chimera-gateway.service chimera-client.service
    else
      (
        cd "$ROOT_DIR"
        run_chimera_cli down --state-file docs/runtime_state_latest.json || true
        run_chimera_gateway doctor --config configs/gateway.example.conf --json --out docs/gateway_doctor_latest.json
        run_chimera_cli up --state-file docs/runtime_state_latest.json
      )
    fi
    start_socks_tunnel
    apply_route_mode
    auto_sync_desktop_proxy_port
    ;;
  status)
    ensure_base_path
    if systemd_user_ready; then
      systemctl --user --no-pager --full status chimera-gateway.service chimera-client.service || true
    else
      echo "systemd_user=unavailable (direct-binary mode)"
    fi
    if [[ -f "$STATE_FILE" ]]; then
      echo
      echo "Runtime state file: $STATE_FILE"
      ls -l "$STATE_FILE"
    else
      echo
      echo "Runtime state file is missing: $STATE_FILE"
    fi
    ;;
  doctor)
    ensure_base_path
    run_chimera_cli doctor --config configs/client.example.conf --json --out docs/doctor_latest.json
    ;;
  logs)
    echo "Gateway log: $GATEWAY_LOG"
    tail -n 80 "$GATEWAY_LOG" 2>/dev/null || true
    echo
    echo "Client log: $CLIENT_LOG"
    tail -n 80 "$CLIENT_LOG" 2>/dev/null || true
    ;;
  proxy-status)
    refresh_socks_port_from_upstream_env
    auto_sync_desktop_proxy_port
    if ss -ltn "( sport = :$SOCKS_PORT )" 2>/dev/null | grep -q "$SOCKS_HOST:$SOCKS_PORT"; then
      echo "socks_tunnel=running $SOCKS_HOST:$SOCKS_PORT"
    else
      echo "socks_tunnel=stopped"
    fi
    echo "upstream_strategy=$UPSTREAM_STRATEGY"
    if [[ -f "$LAST_ENDPOINT_FILE" ]]; then
      echo "upstream_last_endpoint=$(awk -F'|' 'NR==1{print $1}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
      echo "upstream_last_endpoint_sticky_until=$(awk -F'|' 'NR==1{print $2}' "$LAST_ENDPOINT_FILE" 2>/dev/null || true)"
    else
      echo "upstream_last_endpoint=unknown"
    fi
    if [[ -f "$UPSTREAM_HEALTH_STATE_FILE" ]]; then
      # shellcheck disable=SC1090
      source "$UPSTREAM_HEALTH_STATE_FILE"
      echo "upstream_health_listener_up=${listener_up:-unknown}"
      echo "upstream_health_ok=${health_ok:-unknown}"
      echo "upstream_degrade_fails=${degrade_fails:-unknown}"
      echo "upstream_degrade_threshold=${degrade_threshold:-unknown}"
      echo "upstream_last_reason=${last_reason:-unknown}"
      echo "upstream_last_transport=${last_transport:-unknown}"
      echo "upstream_health_ts=${ts:-unknown}"
    else
      echo "upstream_health_state=missing"
    fi
    if desktop_proxy_supported; then
      echo "proxy_mode=$(gsettings get org.gnome.system.proxy mode)"
      echo "proxy_autoconfig_url=$(gsettings get org.gnome.system.proxy autoconfig-url)"
      echo "proxy_socks_host=$(gsettings get org.gnome.system.proxy.socks host)"
      echo "proxy_socks_port=$(gsettings get org.gnome.system.proxy.socks port)"
    else
      echo "proxy_mode=unknown (desktop settings unavailable)"
    fi
    ;;
  app-routes-status)
    print_app_routes_status
    ;;
  route-status)
    print_route_status
    ;;
  route-mode)
    mode="${2:-show}"
    case "$mode" in
      show)
        echo "route_mode=$(read_route_mode)"
        ;;
      full|split|selective|off)
        write_route_mode "$mode"
        apply_route_mode
        auto_sync_desktop_proxy_port
        echo "route_mode_set=$(read_route_mode)"
        ;;
      *)
        echo "error: route-mode must be show|full|split|off" >&2
        exit 1
        ;;
    esac
    ;;
  split-list-mode)
    mode="${2:-show}"
    case "$mode" in
      show)
        echo "split_list_mode=$(read_split_list_mode)"
        ;;
      allow|deny)
        write_split_list_mode "$mode"
        apply_route_mode
        echo "split_list_mode_set=$(read_split_list_mode)"
        ;;
      *)
        echo "error: split-list-mode must be show|allow|deny" >&2
        exit 1
        ;;
    esac
    ;;
  site-add)
    shift || true
    site_add "$@"
    ;;
  site-remove)
    shift || true
    site_remove "$@"
    ;;
  site-list)
    site_list
    ;;
  site-auto-resolve)
    shift || true
    site_auto_resolve_many "$@"
    ;;
  site-auto-status)
    site_adaptive_status
    ;;
  site-auto-watch)
    sub="${2:-status}"
    case "$sub" in
      start) site_auto_watch_start ;;
      stop) site_auto_watch_stop ;;
      status) site_auto_watch_status ;;
      run-once) site_auto_watch_run_once ;;
      *)
        echo "error: site-auto-watch must be start|stop|status|run-once" >&2
        exit 1
        ;;
    esac
    ;;
  upstream-probe)
    upstream_probe
    ;;
  upstream-reset)
    upstream_reset
    ;;
  upstream-audit)
    lines="${2:-30}"
    upstream_audit "$lines"
    ;;
  upstream-failover-smoke)
    wait_sec="${2:-10}"
    upstream_failover_smoke "$wait_sec"
    ;;
  apps-running)
    apps_running
    ;;
  services-running)
    services_running
    ;;
  app-route-add)
    shift || true
    app_id="${1:-}"
    shift || true
    app_route_add "$app_id" "$@"
    ;;
  app-route-add-running)
    shift || true
    app_route_add_running "$@"
    ;;
  service-proxy-enable-running)
    shift || true
    service_proxy_enable_running "$@"
    ;;
  uninstall)
    uninstall_full
    ;;
  run-app)
    shift || true
    run_app_via_proxy "$@"
    ;;
  service-proxy-enable)
    shift || true
    service_proxy_enable "$@"
    ;;
  service-proxy-disable)
    shift || true
    service_proxy_disable "$@"
    ;;
  ui-mode)
    mode="${2:-show}"
    case "$mode" in
      show)
        if [[ -f "$UI_MODE_FILE" ]]; then
          echo "ui_mode=$(cat "$UI_MODE_FILE")"
        else
          echo "ui_mode=auto"
        fi
        ;;
      auto|tray|dialog|cli)
        mkdir -p "$(dirname "$UI_MODE_FILE")"
        printf '%s\n' "$mode" > "$UI_MODE_FILE"
        echo "ui_mode set to: $mode"
        ;;
      *)
        echo "error: ui-mode must be one of auto|tray|dialog|cli|show" >&2
        exit 1
        ;;
    esac
    ;;
  *)
    usage
    exit 1
    ;;
esac
