#!/usr/bin/env bash
set -euo pipefail

export PATH="$HOME/.cargo/bin:$PATH"
ROOT_DIR="$HOME/chimera-pq"
CONTROL="$ROOT_DIR/scripts/chimera-control.sh"
TRAY="$ROOT_DIR/scripts/chimera-control-tray.sh"
LOG_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/chimera"
ENTRY_LOG="$LOG_DIR/desktop-entry.log"
mkdir -p "$LOG_DIR"

{
  echo "--- $(date '+%F %T') desktop-entry start ---"
  echo "session=${XDG_SESSION_TYPE:-unknown} display=${DISPLAY:-none} wayland=${WAYLAND_DISPLAY:-none}"
} >>"$ENTRY_LOG"

choose_action() {
  if command -v zenity >/dev/null 2>&1; then
    zenity --list \
      --title="CHIMERA Control" \
      --text="Choose action" \
      --column="Action" \
      "Start CHIMERA" "Stop CHIMERA" "Restart CHIMERA" "Status" "Doctor" "Logs" "Start Tray Menu" "Quit" \
      --height=380 --width=380 2>/dev/null || true
    return
  fi

  if command -v kdialog >/dev/null 2>&1; then
    kdialog --menu "CHIMERA Control" \
      start "Start CHIMERA" \
      stop "Stop CHIMERA" \
      restart "Restart CHIMERA" \
      status "Status" \
      doctor "Doctor" \
      logs "Logs" \
      tray "Start Tray Menu" \
      quit "Quit" 2>/dev/null || true
    return
  fi

  echo "Status"
}

show_text() {
  local title="$1"
  if command -v zenity >/dev/null 2>&1; then
    zenity --text-info --title="$title" --width=980 --height=720 --filename=/dev/stdin 2>/dev/null || true
    return
  fi
  if command -v kdialog >/dev/null 2>&1; then
    kdialog --textbox /dev/stdin 920 680 2>/dev/null || true
    return
  fi
  cat
}

start_tray() {
  if pgrep -f "chimera-control-tray.sh" >/dev/null 2>&1; then
    return 0
  fi
  nohup "$TRAY" >/dev/null 2>&1 &
}

restart_chromium_with_pac() {
  local chromium_bin="/usr/lib64/chromium/chromium"
  local pac_file="${XDG_CONFIG_HOME:-$HOME/.config}/chimera/chimera-proxy.pac"
  if [[ ! -x "$chromium_bin" ]]; then
    return 0
  fi
  if [[ ! -f "$pac_file" ]]; then
    return 0
  fi
  if ! pgrep -f "$chromium_bin" >/dev/null 2>&1; then
    return 0
  fi
  pkill -f "$chromium_bin" 2>/dev/null || true
  sleep 1
  nohup "$chromium_bin" \
    --ozone-platform=wayland \
    --proxy-pac-url="file://$pac_file" \
    --no-default-browser-check >>"$ENTRY_LOG" 2>&1 &
}

action="$(choose_action)"
echo "action=$action" >>"$ENTRY_LOG"

case "$action" in
  "Start CHIMERA"|start)
    nohup bash -lc "CHIMERA_AUTOFIX_MAX_TIME=20 CHIMERA_AUTOFIX_CURL_MAX_TIME=3 '$CONTROL' start" >>"$ENTRY_LOG" 2>&1 &
    restart_chromium_with_pac
    if command -v notify-send >/dev/null 2>&1; then
      notify-send "CHIMERA Control" "CHIMERA запущена. Chromium перезапущен с PAC split-routing." || true
    fi
    "$CONTROL" proxy-status 2>&1 | show_text "CHIMERA Start (Background)"
    ;;
  "Stop CHIMERA"|stop)
    "$CONTROL" stop 2>&1 | show_text "CHIMERA Stop"
    ;;
  "Restart CHIMERA"|restart)
    "$CONTROL" restart 2>&1 | show_text "CHIMERA Restart"
    ;;
  "Status"|status)
    "$CONTROL" status 2>&1 | show_text "CHIMERA Status"
    ;;
  "Doctor"|doctor)
    (cd "$ROOT_DIR" && cargo run -p chimera-cli -- doctor --config configs/client.example.conf --json --out docs/doctor_latest.json) 2>&1 | show_text "CHIMERA Doctor"
    ;;
  "Logs"|logs)
    "$CONTROL" logs 2>&1 | show_text "CHIMERA Logs"
    ;;
  "Start Tray Menu"|tray)
    start_tray
    if command -v notify-send >/dev/null 2>&1; then
      notify-send "CHIMERA Control" "Tray menu started (if supported by your desktop)." || true
    fi
    ;;
  "Quit"|quit|"")
    exit 0
    ;;
  *)
    "$CONTROL" status 2>&1 | show_text "CHIMERA Status"
    ;;
esac
