CHIMERA PQ runtime package.
Installed by bootstrap chimera.sh.
