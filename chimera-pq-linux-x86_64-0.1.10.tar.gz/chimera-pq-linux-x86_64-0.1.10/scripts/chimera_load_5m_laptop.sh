#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REMOTE_HOST="${CHIMERA_LAPTOP_HOST:-192.168.31.31}"
REMOTE_USER="${CHIMERA_LAPTOP_USER:-art}"
REMOTE_PASS="${CHIMERA_LAPTOP_PASS:-1234}"
REMOTE_REPO="${CHIMERA_LAPTOP_REPO:-/home/art/chimera-pq}"
REMOTE_DURATION_SEC="${CHIMERA_LOAD_DURATION_SEC:-300}"
REMOTE_TIMEOUT_SEC="${CHIMERA_LOAD_TIMEOUT_SEC:-12}"
REMOTE_CONNECT_TIMEOUT_SEC="${CHIMERA_LOAD_CONNECT_TIMEOUT_SEC:-5}"
OUT_DIR="${1:-$ROOT_DIR/docs/load}"
TS="$(date +%Y%m%d_%H%M%S)"
LOCAL_OUT="$OUT_DIR/CHIMERA_LOAD_${REMOTE_DURATION_SEC}S_LAPTOP_${TS}.json"

mkdir -p "$OUT_DIR"

if ! command -v sshpass >/dev/null 2>&1; then
  echo "chimera-load-5m-laptop: sshpass is required" >&2
  exit 1
fi

read -r -d '' PY_CODE <<'PY' || true
import json, subprocess, threading, time, sys
from collections import defaultdict

proxy=sys.argv[1]
out=sys.argv[2]
duration=int(sys.argv[3])
connect_timeout=sys.argv[4]
max_time=sys.argv[5]

sites=[
  "https://youtube.com",
  "https://aistudio.google.com",
  "https://chat.openai.com",
  "https://openai.com",
  "https://epicgames.com",
  "https://www.googleadservices.com",
]

stop=time.time()+duration
lock=threading.Lock()
stats={s:{"ok":0,"fail":0,"codes":defaultdict(int),"last_error":""} for s in sites}

def worker(site):
  while time.time()<stop:
    p=subprocess.run(
      ["curl","-sS","-L","--proxy",proxy,
       "--connect-timeout",connect_timeout,
       "--max-time",max_time,
       "-o","/dev/null","-w","%{http_code}",site],
      capture_output=True,text=True
    )
    code=(p.stdout or "").strip() or "000"
    with lock:
      if p.returncode==0 and code!="000":
        stats[site]["ok"]+=1
      else:
        stats[site]["fail"]+=1
        err=(p.stderr or "").strip()
        if err:
          stats[site]["last_error"]=err.splitlines()[-1][:300]
      stats[site]["codes"][code]+=1

threads=[threading.Thread(target=worker,args=(s,),daemon=True) for s in sites]
for t in threads:
  t.start()
for t in threads:
  t.join()

res={
  "kind":"chimera_load_test",
  "duration_sec":duration,
  "proxy":proxy,
  "generated_at":int(time.time()),
  "sites":[]
}
for s,v in stats.items():
  total=v["ok"]+v["fail"]
  res["sites"].append({
    "site":s,
    "ok":v["ok"],
    "fail":v["fail"],
    "success_rate":(v["ok"]/total if total else 0.0),
    "codes":dict(v["codes"]),
    "last_error":v["last_error"],
  })

with open(out,"w",encoding="utf-8") as f:
  json.dump(res,f,ensure_ascii=False)

print(out)
PY

REMOTE_CMD=$(
  cat <<EOF
set -euo pipefail
cd "$REMOTE_REPO"
proxy_url="\$(bash scripts/chimera-control.sh route-status | sed -n 's/^chimera_proxy_url=//p' | head -n 1)"
[ -n "\$proxy_url" ] || proxy_url="socks5h://127.0.0.1:11080"
tmp_out="docs/CHIMERA_LOAD_${REMOTE_DURATION_SEC}S_${TS}.json"
python3 - "\$proxy_url" "\$tmp_out" "$REMOTE_DURATION_SEC" "$REMOTE_CONNECT_TIMEOUT_SEC" "$REMOTE_TIMEOUT_SEC" <<'PY'
$PY_CODE
PY
sed -n '1,260p' "\$tmp_out"
echo
echo "__REMOTE_OUT__=\$tmp_out"
EOF
)

REMOTE_OUTPUT="$(sshpass -p "$REMOTE_PASS" ssh -o StrictHostKeyChecking=no "$REMOTE_USER@$REMOTE_HOST" "$REMOTE_CMD")"
printf '%s\n' "$REMOTE_OUTPUT"

REMOTE_OUT_PATH="$(printf '%s\n' "$REMOTE_OUTPUT" | awk -F= '/^__REMOTE_OUT__=/{print $2; exit}')"
if [[ -z "$REMOTE_OUT_PATH" ]]; then
  echo "chimera-load-5m-laptop: failed to discover remote output path" >&2
  exit 1
fi

sshpass -p "$REMOTE_PASS" scp -o StrictHostKeyChecking=no \
  "$REMOTE_USER@$REMOTE_HOST:$REMOTE_REPO/$REMOTE_OUT_PATH" "$LOCAL_OUT" >/dev/null

echo "local_artifact=$LOCAL_OUT"
